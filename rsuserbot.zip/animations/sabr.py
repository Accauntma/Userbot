import asyncio
from telethon import TelegramClient, events, sync
import plugins.client
from time import sleep
import time

client = plugins.client.client

class Sabr:
	sabr= ["""
░▉▉░░░
▉░░░░░
░░░░░░""",
"""
░░░▉▉░
░░░░░▉
░░░░░░""",
"""
░░░░░░
░░░░░▉
░░░▉▉░""",
"""
░░░░░░
▉░░░░░
░▉▉░░░""",
"""
░▉▉░░░
▉░░░░░
░░░░░░""",
"""
░░░▉▉░
░░░░░▉
░░░░░░""",
"""
░░░░░░
░░░░░▉
░░░▉▉░""",
"""
░░░░░░
▉░░░░░
░▉▉░░░"""]

sabr = Sabr
@events.register(events.NewMessage)
async def sabrma(event):
		if '.sabr' in event.raw_text:
			time.sleep(0.3)
			for j in Sabr.sabr:
				time.sleep(0.3)
				await event.edit(j)


with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(sabrma)
