from telethon.sync import TelegramClient, events
from telethon.tl import functions
import plugins.client
import time

client=plugins.client.client

class Online:
    online = ["😀", "😃", "😄", "😁", "😆", "😅", "😂", "🤣", "😊", "😇", "🙂", "🙃", "😉", "😌", "😍", "🥰", "😘", "😗", "😙", "😚", "😋", "😛", "😝", "😜", "🤪", "🤨", "🧐", "🤓", "😎", "🤩", "🥳", "👻", "😏", "🥺"]
    
smile = Online()
@events.register(events.NewMessage)
async def smilehandler(event):
	        if ".smile" in event.raw_text:
	        	time.sleep(0.3)
	        	for d in smile.online:
	        		time.sleep(0.3)
	        		await event.edit(d)
	        	
with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(smilehandler)