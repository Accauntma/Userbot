from telethon import TelegramClient, events, sync
from plugins.client import client
import time

client = client

class Friday:
    messages = ["""🕌""","""──╔╗
──║║
──║╠╗╔╦╗╔╦══╗
╔╗║║║║║╚╝║╔╗║
║╚╝║╚╝║║║║╔╗╠╦╦╦╦╗
╚══╩══╩╩╩╩╝╚╩╩╩╩╩╝""","""╔═╗╔═╗──╔╗─────────╔╗
║║╚╝║║──║║─────────║║
║╔╗╔╗╠╗╔╣╚═╦══╦═╦══╣║╔╗
║║║║║║║║║╔╗║╔╗║╔╣╔╗║╚╝╝
║║║║║║╚╝║╚╝║╚╝║║║╔╗║╔╗╗
╚╝╚╝╚╩══╩══╩══╩╝╚╝╚╩╝╚╝""","""◍ Juma Muborak! Qadrdonlar (◍•ᴗ•◍)"""]

@events.register(events.NewMessage)
async def friday(event):
    if '.juma' in event.raw_text:
        time.sleep(0.1)
        for message in Friday.messages:
            time.sleep(1)
            await event.edit(message)

with client as Rs_Userbot:
    Rs_Userbot.add_event_handler(friday)