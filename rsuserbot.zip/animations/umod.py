import asyncio
from telethon import TelegramClient, events, sync
import plugins.client
from time import sleep
import time

client = plugins.client.client

class Ket:
	ket = ["""
░░░░░░🚜░░░░░░🏠
█████████████████
""",
"""
░░░░░░🚜░░░░░🚶🏠
█████████████████
""",
"""
░░░░░░🚜░░░░🚶░🏠
█████████████████
""",
"""
░░░░░░🚜░░🚶░░░🏠
█████████████████
""",
"""
░░░░░░🚜🚶░░░░░🏠
█████████████████
""",
"""
░░░░░░🚜░░░░░░░🏠
█████████████████
""",
"""
░░░░░🚜░░░░░░░░🏠
█████████████████
""",
"""
░░░░🚜░░░░░░░░░🏠
█████████████████
""",
"""
░░░🚜░░░░░░░░░░🏠
█████████████████
""",
"""
░🚜░░░░░░░░░░░░🏠
█████████████████
""",
"""
🚜░░░░░░░░░░░░░🏠
█████████████████""",
"""
░░░░░░░░░░░░░░░🏠
█████████████████
"""]


ket = Ket
@events.register(events.NewMessage)
async def yuraku(event):
		if '.ket' in event.raw_text:
			time.sleep(0.3)
			for g in Ket.ket:
				time.sleep(0.3)
				await event.edit(g)


with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(yuraku)