import asyncio
from telethon import TelegramClient, events, sync
import plugins.client
from time import sleep
import time

client = plugins.client.client

class Reklama:
	reklama = ["""
❤✨✨✨✨✨✨✨✨✨
✨       🌙 𝓙𝓾𝓶𝓪 𝓶𝓾𝓫𝓸𝓻𝓪𝓴        ✨
✨✨✨✨✨✨✨✨✨❤
""",
"""
❤💖✨✨✨✨✨✨✨✨
✨___** obuna bo'ling @UzoMedia **__ ✨
✨✨✨✨✨✨✨✨💖❤
""",
"""
❤✨💖✨✨✨✨✨✨✨
✨       🌙 𝓙𝓾𝓶𝓪 𝓶𝓾𝓫𝓸𝓻𝓪𝓴        ✨
✨✨✨✨✨✨✨💖✨❤
""",
"""
❤✨✨💖✨✨✨✨✨✨
✨__** obuna bo'ling @UzoMedia**__  ✨
✨✨✨✨✨✨💖✨✨❤
""",
"""
❤✨✨✨💖✨✨✨✨✨
✨       🌙 𝓙𝓾𝓶𝓪 𝓶𝓾𝓫𝓸𝓻𝓪𝓴        ✨
✨✨✨✨✨💖✨✨✨❤
""",
"""
❤✨✨✨✨💖✨✨✨✨
✨__** obuna bo'ling @UzoMedia **__.  ✨
✨✨✨✨💖✨✨✨✨❤
""",
"""
❤✨✨✨✨✨💖✨✨✨
✨       🌙 𝓙𝓾𝓶𝓪 𝓶𝓾𝓫𝓸𝓻𝓪𝓴        ✨
✨✨✨💖✨✨✨✨✨❤
""",
"""
❤✨✨✨✨✨✨💖✨✨
✨__** obuna bo'ling @UzoMedia **__  ✨
✨✨💖✨✨✨✨✨✨❤
""",
"""
❤✨✨✨✨✨✨✨💖✨
✨       🌙 𝓙𝓾𝓶𝓪 𝓶𝓾𝓫𝓸𝓻𝓪𝓴        ✨
✨💖✨✨✨✨✨✨✨❤
""",
"""
❤✨✨✨✨✨✨✨✨💖
✨ obuna bo'ling @UzoMedia . ✨
💖✨✨✨✨✨✨✨✨❤"""]


reklama = Reklama
@events.register(events.NewMessage)
async def Rek(event):
		if '.kun' in event.raw_text:
			time.sleep(0.1)
			for g in Reklama.reklama:
				time.sleep(0.8)
				await event.edit(g)


with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(Rek)