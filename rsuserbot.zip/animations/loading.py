from telethon import TelegramClient, events
import asyncio
import time
import random
import plugins.client

client= plugins.client.client


@events.register(events.NewMessage(pattern='.load$', outgoing=True))
async def loading_a(event: events.NewMessage.Event):
    try:
        percentage = 0
        while percentage < 100:
            temp = 100 - percentage
            temp = temp if temp > 5 else 5
            percentage += temp / random.randint(5, 10)
            percentage = round(percentage, 2)

            progress = int(percentage // 5)
            await event.edit(f'|{"█" * progress}{"-" * (20 - progress)}| {percentage}%')
            await asyncio.sleep(.5)

        time.sleep(5)
        await event.delete()

    except Exception as e:
        await event.edit(f"ᴇʀʀᴏʀ » {e}")
        
with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(loading_a)