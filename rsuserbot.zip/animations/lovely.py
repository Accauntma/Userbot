from telethon.sync import TelegramClient, events
from telethon.tl import functions
import plugins.client
import time

client=plugins.client.client

class Lovely:
	lovely = ["""
(\_/)                        (\_/)
( •_•)                       (•_• )
/>❤️                     ❤️<\
""", 
"""
(\_/)                       (\_/)
( •_•)                      (•_• )
/>❤️                    ❤️<\
""",
"""
(\_/)                      (\_/)
( •_•)                     (•_• )
/>❤️                   ❤️<\
""",
"""
(\_/)                     (\_/)
( •_•)                    (•_• )
/>❤️                  ❤️<\
""",
"""
(\_/)                    (\_/)
( •_•)                   (•_• )
/>❤️                 ❤️<\
""",

"""
(\_/)                   (\_/)
( •_•)                  (•_• )
/>❤️                ❤️<\
""",

"""
(\_/)                  (\_/)
( •_•)                 (•_• )
/>❤️               ❤️<\
""",
"""
(\_/)                 (\_/)
( •_•)                (•_• )
/>❤️              ❤️<\
""",

"""
(\_/)              (\_/)
( •_•)             (•_• )
/>❤️            ❤️<\
""",
"""
(\_/)               (\_/)
( •_•)              (•_• )
/>❤️            ❤️<\
""",
"""
(\_/)             (\_/)
( •_•)            (•_• )
/>❤️           ❤️<\
""",
"""
(\_/)         (\_/)
( •_•)        (•_• )
/>❤️      ❤️<\
""",
"""
(\_/)        (\_/)
( •_•)       (•_• )
/>❤️     ❤️<\
""",
"""
(\_/)     (\_/)
( •_•)    (•_• )
/>❤️  ❤️<\
""",
"""
(\_/)   (\_/)
( •_•)  (•_• )
/>❤️❤️<\
""",
"""
❤️.
""",
"""
❤️ ɪ
""",
"""
❤️ ɪ • ʟ
""",
"""
❤️ ɪ • ʟ ᴏ
""",
"""
❤️ ɪ • ʟ ᴏ ᴠ
""",
"""
❤️ ɪ • ʟ ᴏ ᴠ ᴇ
""",
"""
❤️ ɪ • ʟ ᴏ ᴠ ᴇ • ʏ 
""",
"""
❤️ ɪ • ʟ ᴏ ᴠ ᴇ • ʏ ᴏ
""",
"""
❤️ ɪ • ʟ ᴏ ᴠ ᴇ • ʏ ᴏ ᴜ
"""]

lovely = Lovely
@events.register(events.NewMessage)
async def lovely(event):
		if '.lovely' in event.raw_text:
			time.sleep(0.3)
			for d in Lovely.lovely:
				time.sleep(0.3)
				await event.edit(d)
		
with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(lovely)