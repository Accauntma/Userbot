from asyncio import sleep
from telethon import functions
from random import randint
from telethon.tl import types
from telethon.sync import events
from telethon.tl.types import InputMediaDice
from telethon.sync import TelegramClient
from telethon.sessions import StringSession
import plugins.client

client=plugins.client.client


# Start the client
with client:
    class FakeMod:
        """Imitates your actions"""

        # Define a constructor for initialization
        def __init__(self, client):
            self.client = client

        async def roundcmd(self, message):
            """Imitates round"""
            activity_time = message.text.split(' ', 1)[1]
            await message.delete()
            try:
                async with self.client.action(message.chat_id, "round"):
                    await sleep(int(activity_time))
            except BaseException:
                return
        
        
        async def stickcmd(self, message):
            """Imitates stick"""
            activity_time = message.text.split(' ', 1)[1]
            await message.delete()
            try:
                async with self.client.action(message.chat_id, "sticker"):
                    await sleep(int(activity_time))
            except BaseException:
                return
        
        async def contactcmd(self, message):
            """Imitates contact"""
            activity_time = message.text.split(' ', 1)[1]
            await message.delete()
            try:
                async with self.client.action(message.chat_id, "contact"):
                    await sleep(int(activity_time))
            except BaseException:
                return
        
        async def locationcmd(self, message):
            """Imitates location"""
            activity_time = message.text.split(' ', 1)[1]
            await message.delete()
            try:
                async with self.client.action(message.chat_id, "location"):
                    await sleep(int(activity_time))
            except BaseException:
                return        
        
        async def typecmd(self, message):
            """Imitates typing"""
            activity_time = message.text.split(' ', 1)[1]
            await message.delete()
            try:
                async with self.client.action(message.chat_id, "typing"):
                    await sleep(int(activity_time))
            except BaseException:
                return

        async def voicecmd(self, message):
            """Imitates sending voices"""
            activity_time = message.text.split(' ', 1)[1]
            await message.delete()
            try:
                async with self.client.action(message.chat_id, "voice"):
                    await sleep(int(activity_time))
            except BaseException:
                return

        async def gamecmd(self, message):
            """Imitates your game activity"""
            activity_time = message.text.split(' ', 1)[1]
            await message.delete()
            try:
                async with self.client.action(message.chat_id, "game"):
                    await sleep(int(activity_time))
            except BaseException:
                return

        async def videocmd(self, message):
            """Imitates sending video"""
            activity_time = message.text.split(' ', 1)[1]
            await message.delete()
            try:
                async with self.client.action(message.chat_id, "video"):
                    await sleep(int(activity_time))
            except BaseException:
                return

        async def photocmd(self, message):
            """Imitates sending photo"""
            activity_time = message.text.split(' ', 1)[1]
            await message.delete()
            try:
                async with self.client.action(message.chat_id, "photo"):
                    await sleep(int(activity_time))
            except BaseException:
                return

        async def documentcmd(self, message):
            """Imitates sending document"""
            activity_time = message.text.split(' ', 1)[1]
            await message.delete()
            try:
                async with self.client.action(message.chat_id, "document"):
                    await sleep(int(activity_time))
            except BaseException:
                return

    # ... (previous code)

    # Register event handlers for the commands
    
    
    @events.register(events.NewMessage(pattern=r'\.fakeround', outgoing=True))
    async def round_fake(event):
        fake_mod = FakeMod(client)
        await fake_mod.roundcmd(event.message)
    
    @events.register(events.NewMessage(pattern=r'\.fakestick', outgoing=True))
    async def stick_fake(event):
        fake_mod = FakeMod(client)
        await fake_mod.stickcmd(event.message)
    
    @events.register(events.NewMessage(pattern=r'\.fakecon', outgoing=True))
    async def con_fake(event):
        fake_mod = FakeMod(client)
        await fake_mod.contactcmd(event.message)
    
    @events.register(events.NewMessage(pattern=r'\.fakeloc', outgoing=True))
    async def loc_fake(event):
        fake_mod = FakeMod(client)
        await fake_mod.locationcmd(event.message)    
    
    @events.register(events.NewMessage(pattern=r'\.faketype', outgoing=True))
    async def type_fake(event):
        fake_mod = FakeMod(client)
        await fake_mod.typecmd(event.message)

    @events.register(events.NewMessage(pattern=r'\.fakevoice', outgoing=True))
    async def voice_fake(event):
        fake_mod = FakeMod(client)
        await fake_mod.voicecmd(event.message)

    @events.register(events.NewMessage(pattern=r'\.fakegame', outgoing=True))
    async def game_fake(event):
        fake_mod = FakeMod(client)
        await fake_mod.gamecmd(event.message)

    @events.register(events.NewMessage(pattern=r'\.fakevideo', outgoing=True))
    async def video_fake(event):
        fake_mod = FakeMod(client)
        await fake_mod.videocmd(event.message)

    @events.register(events.NewMessage(pattern=r'\.fakephoto', outgoing=True))
    async def photo_fake(event):
        fake_mod = FakeMod(client)
        await fake_mod.photocmd(event.message)

    @events.register(events.NewMessage(pattern=r'\.fakedcmt', outgoing=True))
    async def document_fake(event):
        fake_mod = FakeMod(client)
        await fake_mod.documentcmd(event.message)
        

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(con_fake)


with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(round_fake)


with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(stick_fake)

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(type_fake)


with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(loc_fake)



with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(game_fake)
	
	
	
with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(video_fake)
	
			
with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(photo_fake)
	
	
with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(document_fake)	

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(voice_fake)