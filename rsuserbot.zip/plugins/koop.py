from telethon import TelegramClient, events
from plugins.client import client
import os
import time
import asyncio

client = client
        
@events.register(events.NewMessage(pattern='.kop', outgoing=True))
async def kop(event):
    msg = event.message.text.split()
    xabar = msg[2:]
    await event.delete()
    ints = int(msg[1]) - 0
    while ints > 0:
        await client.send_message(event.message.to_id, " ".join(xabar))
        ints -= 1
                
with client as Rs_Userbot:
 Rs_Userbot.add_event_handler(kop)