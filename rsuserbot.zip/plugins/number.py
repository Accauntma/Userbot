from telethon import TelegramClient, events, sync
from time import sleep
from datetime import datetime
import asyncio, aiocron, datetime
import asyncio
from telethon import TelegramClient, events, sync, functions, types, Button
from plugins import client
from telethon.tl.functions.account import UpdateProfileRequest

client = client.client

@events.register(events.NewMessage(outgoing=True, pattern=".num"))
async def numbers(event):
        msg=event.message.raw_text.split()
        t=int(msg[1])
        await event.delete()
        while t>0:
                sleep(1)
                await client.send_message(event.message.to_id,str(t))
                t-=1

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(numbers)