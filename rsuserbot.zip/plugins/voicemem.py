#2023 (ᴄ) ʀs ᴅᴇᴠᴇʟᴏᴘᴇʀ ᴋɢ 

from telethon import TelegramClient, events
from asyncio import sleep
import plugins.client
import time

client=plugins.client.client



@events.register(events.NewMessage(pattern='.voicemem',outgoing=True))
async def voicemem(event):
	await event.edit("[ᴠᴏɪᴄᴇ ᴍᴇᴍs 😂]\n\n`.edlb` ᴇ ᴅᴀʟʙᴀʏᴏʙ ᴜɴᴅᴀʏ ᴅᴇɢᴀɴɪᴍ ʏᴏǫ ᴍᴇɴ 😠\n`.ovdlb` ᴏᴠ ᴅᴀʟʙᴀʏᴏᴏʙ 🙄\n`.mangap` ᴍᴀɴɢᴀ ᴘ sᴀɴɢᴀᴄʜɪ 😂\n`.ngjim` ɴᴇɢᴀ ᴊɪᴍsɪʟᴀʀ 🤐\n`.sbchami` sᴀʙᴀᴄʜᴋᴀ ᴀᴍɪ 🤣\n`.nimagap` ɴɪᴍᴀ ɢᴀᴘ 🤔\n`.snxrm` ʙᴜʟᴜᴛʟᴀʀ ᴋᴏᴛᴀʀᴀʀ ᴏᴛᴀɴɢɴɪ ǫᴏᴛᴏɢɪ ʏᴀɴᴀ ᴛɪɢᴜʟᴀʀ sᴀɴᴅᴀʏ xᴀʀᴏᴍɪ 😹\n`.pnxg` ᴘᴀsʜᴏʟ ɴᴀxᴜʏ ɢᴀɴᴅᴏɴ - ʀᴜ 🇷🇺😂\n`.slmq` sᴀʟᴏᴍʟᴀʀ ǫᴏᴛᴏɢʟᴀʀ 😂👋\n`.valo` ᴀʟᴏ 🗣\n`.iyuqdrl` ɪʏᴜ ǫᴏᴅɪʀᴀʟɪ 😳\n`.qndeyz` ǫᴀɴᴅᴀʏ ᴇʏ ᴢᴏʀᴍɪsᴀɴ ᴀʏ 😊\n`.drchqima` ᴅʀᴀᴄʜɪᴛ ǫɪᴍᴀ ɢᴀɴᴅᴏɴ 😹\n`.drchqisen` ǫᴀʏsɪɴ ᴅʀᴀᴄʜɪᴛ ǫɪʟsᴇɴ sɪᴋᴀᴍᴀɴ ɴᴀxᴜʏ 😂\n`.buninmal` [ ɪsᴋᴀɴᴅᴀʀ] ʙᴜɴɪ ɴɪᴍᴀ ᴅᴀʜʟɪ ʙᴏʀ ᴅᴀʟʙᴀʏᴏʙ 😹\n`.homqt` [ɪsᴋᴀɴᴅᴀʀ] ʜᴏᴍ ʜᴀʏᴏʟɢᴀ ʜᴏᴍ ǫᴏᴛᴏɢ 🤣\n`.sqnbosa` sᴏǫǫᴇɴ ʙᴏsᴀ 💸😆\n`.dnxrek` ɪᴅɪɴᴀxᴜʏ ᴜɴɪᴠᴇʀsᴀʟɴɪʏ 😊😹\n`.ksikishmelar` [ᴄʜɪɴɢɪᴢ] ᴋᴏᴘ sɪᴋɪsʜᴍᴇʟᴀʀ ɴᴀxᴜʏ 🔞😂\n`.hqtb` [ʙᴇᴄᴋᴏʀᴇ] ʜᴀ ǫᴏᴛᴏʙᴏsʜ ɴɪᴍᴀ ɢᴀᴘ 😏\n`.obmsn` ᴏ ʙᴏʀᴍɪsᴀɴ ᴏᴅᴀᴍᴅɪ ᴏʜɪʀɢɪ sᴏʀᴛɪ 🤣\n`.chqdrl` [ᴄʜɪɴɢɪᴢ] ǫᴏᴅɪʀᴀʟɪ 😂\n`.bmsdnx` [sᴏʙɪʀ.ᴅᴇ] ʙᴏᴍᴀsᴀᴍ ɪᴅɪɴᴀxᴜʏ 🙄\n`.byqch` ʙᴜʏᴏǫᴀ ᴄʜɪǫɪɴ ᴏɴᴀɴɢᴅɪ sɪᴋᴀʏ 😑")


# ᴇ ᴅᴀʟʙᴀʏᴏʙ ᴜɴᴅᴀʏ ᴅᴇɢᴀɴɪᴍ ʏᴏǫ ᴍᴇɴ 


@events.register(events.NewMessage(pattern='.edlb',outgoing=True))
async def edlb(event):
    reply = await event.get_reply_message()
    await event.delete()
    await event.client.send_file(event.to_id, "https://t.me/rsuserbotvoicemems/31", voice_note=True, reply_to=reply.id if reply else None)

#sᴀʙᴀᴄʜᴋᴀ ᴀᴍɪ 😂


@events.register(events.NewMessage(pattern='.sbchami',outgoing=True))
async def sbchami(event):
    reply = await event.get_reply_message()
    await event.delete()
    await event.client.send_file(event.to_id, "https://t.me/rsuserbotvoicemems/115", voice_note=True, reply_to=reply.id if reply else None)



#ᴏᴠ ᴅᴀʟʙᴀʏᴏʙ

@events.register(events.NewMessage(pattern='.ovdlb',outgoing=True))
async def ovdlb(event):
    reply = await event.get_reply_message()
    await event.delete()
    await event.client.send_file(event.to_id, "https://t.me/rsuserbotvoicemems/103", voice_note=True, reply_to=reply.id if reply else None)



#ᴘᴀsʜᴏʟ ɴᴀxᴜʏ ɢᴀɴᴅᴏɴ

@events.register(events.NewMessage(pattern='.pnxg',outgoing=True))
async def pnxg(event):
    reply = await event.get_reply_message()
    await event.delete()
    await event.client.send_file(event.to_id, "https://t.me/rsuserbotvoicemems/32", voice_note=True, reply_to=reply.id if reply else None)



#ᴍᴀɴɢᴀ ᴘ sᴀɴɢᴀᴄʜɪ ?


@events.register(events.NewMessage(pattern='.mangap',outgoing=True))
async def mangap(event):
    reply = await event.get_reply_message()
    await event.delete()
    await event.client.send_file(event.to_id, "https://t.me/rsuserbotvoicemems/25", voice_note=True, reply_to=reply.id if reply else None)


#sᴀʟᴏᴍʟᴀʀ ǫᴏᴛᴏʟᴀʀ 😂


@events.register(events.NewMessage(pattern='.slmq',outgoing=True))
async def slmq(event):
    reply = await event.get_reply_message()
    await event.delete()
    await event.client.send_file(event.to_id, "https://t.me/rsuserbotvoicemems/28", voice_note=True, reply_to=reply.id if reply else None)


#ɴᴇɢᴀ ᴊɪᴍsɪʟᴀʀ 🤔

@events.register(events.NewMessage(pattern='.ngjim',outgoing=True))
async def ngjim(event):
    reply = await event.get_reply_message()
    await event.delete()
    await event.client.send_file(event.to_id, "https://t.me/rsuserbotvoicemems/27", voice_note=True, reply_to=reply.id if reply else None)


#ʙᴜʟᴜᴛʟᴀʀ ᴋᴏᴛᴀʀᴀʀ ᴏᴛᴀɴɢɴɪ ǫᴏᴛᴏɢɪ ʏᴀɴᴀ ᴛᴜɢᴜʟᴀʀ sᴇɴᴅᴇʏ ʜᴀʀᴏᴍɪ 😂

#ᴋᴏᴅɴɪ ǫᴏᴛᴏɢᴀ ᴄʜᴜǫᴜᴠᴏsᴀɴᴍɪ ɢᴀɴᴅᴏɴ ɴx



@events.register(events.NewMessage(pattern='.snxrm',outgoing=True))
async def snxrm(event):
    reply = await event.get_reply_message()
    await event.delete()
    await event.client.send_file(event.to_id, "https://t.me/rsuserbotvoicemems/15", voice_note=True, reply_to=reply.id if reply else None)


#ɴɪᴍᴀ ɢᴀᴘ 🙄


#ᴋᴏᴅᴀ ᴏᴛɪ ǫᴏᴛᴏɢɪ ʙᴏʀᴍɪᴋᴀɴ ǫᴀʀᴀᴠᴏsᴀɴ ᴏʟᴅɪɴ ɪsʜʟᴀᴛɪsʜɴɪ ᴏʀɢᴀɴɪʙ ᴏʟ sᴏsᴋᴀ ʙʟᴇ 😂😃🐑



@events.register(events.NewMessage(pattern='.nimagap',outgoing=True))
async def nimagap(event):
    reply = await event.get_reply_message()
    await event.delete()
    await event.client.send_file(event.to_id, "https://t.me/rsuserbotvoicemems/107", voice_note=True, reply_to=reply.id if reply else None)



#ᴀʟᴏ 

#ɢᴀɴᴅᴏɴ ᴠᴏᴄʜᴀ ǫᴏᴛᴏɢᴀ ᴋᴏᴅɢᴀ ǫᴀʀᴀᴠᴏsᴀɴᴍɪ ᴏʟᴅɪɴ ɪsʜʟᴀᴛɪsʜɴɪ ᴏʀɢsɴɪʙ ᴋᴇ sᴏsᴋᴇ 🙄😹

@events.register(events.NewMessage(pattern='.valo',outgoing=True))
async def alo(event):
    reply = await event.get_reply_message()
    await event.delete()
    await event.client.send_file(event.to_id, "https://t.me/rsuserbotvoicemems/21", voice_note=True, reply_to=reply.id if reply else None)



#ɪʏᴜ ǫᴏᴅɪʀᴀʟɪ 😳


#ᴋᴏᴅ ɪᴄʜɪᴅᴀ ǫᴏᴛᴏɢ ʙᴏʀ sᴏʀɪᴍ ᴏʟ ᴜᴋᴀ 😂


@events.register(events.NewMessage(pattern='.iyuqdrl',outgoing=True))
async def iyuqdrl(event):
    reply = await event.get_reply_message()
    await event.delete()
    await event.client.send_file(event.to_id, "https://t.me/rsuserbotvoicemems/18", voice_note=True, reply_to=reply.id if reply else None)



#ǫᴀɴᴅᴀʏ ᴇʏ ᴢᴏʀᴍɪsᴀɴ ᴀʏ 😃


#ǫᴏʏɪʟ ʟᴇᴋɪɴ ɢɪʀᴛ ᴋᴏᴅ ᴄʜᴏᴘᴀʀ ᴇᴋᴀɴsᴀɴ ᴋᴏᴅ ɢᴀ ǫᴀʀᴀʙ ᴏᴛɪʀᴍᴀsᴅᴀɴ sᴜʀ ɴᴀxᴜʏ ᴋᴀʟᴇɴɢᴀ ǫᴏᴛᴏɢɪᴍ 😂

@events.register(events.NewMessage(pattern='.qndeyz',outgoing=True))
async def qndeyz(event):
    reply = await event.get_reply_message()
    await event.delete()
    await event.client.send_file(event.to_id, "https://t.me/rsuserbotvoicemems/110", voice_note=True, reply_to=reply.id if reply else None)



#sᴀɴ sᴜᴋᴀ ǫᴀɴᴅᴇ ᴏᴅᴀᴍsᴀɴᴇ ᴋᴀʟᴇɴɢᴀ ǫᴏᴛᴏɢɪᴍ 😹 sʜᴜ ʏᴇʀɢᴀᴄʜᴀʜᴀᴍ ᴋᴇʟᴅɪɴɢᴍɪ ᴅᴇᴍᴇ sᴇɴ ɢɪʀᴛ ᴊᴀʟᴀʙᴅɪ ʙᴏʟᴀsɪsᴀɴ ᴇxxx sᴏsᴋᴀᴠᴏʏ



@events.register(events.NewMessage(pattern='.drchqima',outgoing=True))
async def drchqima(event):
    reply = await event.get_reply_message()
    await event.delete()
    await event.client.send_file(event.to_id, "https://t.me/rsuserbotvoicemems/69", voice_note=True, reply_to=reply.id if reply else None)


@events.register(events.NewMessage(pattern='.drchqisen',outgoing=True))
async def drchqisen(event):
    reply = await event.get_reply_message()
    await event.delete()
    await event.client.send_file(event.to_id, "https://t.me/rsuserbotvoicemems/55", voice_note=True, reply_to=reply.id if reply else None)


@events.register(events.NewMessage(pattern='.buninmal',outgoing=True))
async def buninmal(event):
    reply = await event.get_reply_message()
    await event.delete()
    await event.client.send_file(event.to_id, "https://t.me/rsuserbotvoicemems/71", voice_note=True, reply_to=reply.id if reply else None)



@events.register(events.NewMessage(pattern='.homqt',outgoing=True))
async def homqt(event):
    reply = await event.get_reply_message()
    await event.delete()
    await event.client.send_file(event.to_id, "https://t.me/rsuserbotvoicemems/70", voice_note=True, reply_to=reply.id if reply else None)



@events.register(events.NewMessage(pattern='.sqnbosa',outgoing=True))
async def sqnbosa(event):
    reply = await event.get_reply_message()
    await event.delete()
    await event.client.send_file(event.to_id, "https://t.me/rsuserbotvoicemems/94", voice_note=True, reply_to=reply.id if reply else None)



#ᴇ ǫᴀʏᴅᴀɴ ᴋᴇʟᴅɪ ʙᴜ ʜᴀʀᴏᴍɪ ǫᴏᴄʜ ᴏɴᴀʜɢɴɪ sɪᴋᴀʏ ᴀᴅᴅ ʜᴀɴᴅʟᴇʀ ᴅᴀ ǫᴏᴛᴏ ʙᴏʀᴍɪ sᴀɴɢᴀ sᴏsᴋᴀ ʜᴀʀᴏᴍɪ 😹


@events.register(events.NewMessage(pattern='.dnxrek',outgoing=True))
async def dnxrek(event):
    reply = await event.get_reply_message()
    await event.delete()
    await event.client.send_file(event.to_id, "https://t.me/rsuserbotvoicemems/100", voice_note=True, reply_to=reply.id if reply else None)




@events.register(events.NewMessage(pattern='.ksikishmelar',outgoing=True))
async def ksikishmelar(event):
    reply = await event.get_reply_message()
    await event.delete()
    await event.client.send_file(event.to_id, "https://t.me/rsuserbotvoicemems/72", voice_note=True, reply_to=reply.id if reply else None)



@events.register(events.NewMessage(pattern='.hqtb',outgoing=True))
async def hqtb(event):
    reply = await event.get_reply_message()
    await event.delete()
    await event.client.send_file(event.to_id, "https://t.me/rsuserbotvoicemems/83", voice_note=True, reply_to=reply.id if reply else None)



@events.register(events.NewMessage(pattern='.obmsn',outgoing=True))
async def obmsn(event):
    reply = await event.get_reply_message()
    await event.delete()
    await event.client.send_file(event.to_id, "https://t.me/rsuserbotvoicemems/82", voice_note=True, reply_to=reply.id if reply else None)





@events.register(events.NewMessage(pattern='.chqdrl',outgoing=True))
async def chqdrl(event):
    reply = await event.get_reply_message()
    await event.delete()
    await event.client.send_file(event.to_id, "https://t.me/rsuserbotvoicemems/91", voice_note=True, reply_to=reply.id if reply else None)



@events.register(events.NewMessage(pattern='.bmsdnx',outgoing=True))
async def bmsdnx(event):
    reply = await event.get_reply_message()
    await event.delete()
    await event.client.send_file(event.to_id, "https://t.me/rsuserbotvoicemems/102", voice_note=True, reply_to=reply.id if reply else None)


@events.register(events.NewMessage(pattern='.byqch',outgoing=True))
async def byqch(event):
    reply = await event.get_reply_message()
    await event.delete()
    await event.client.send_file(event.to_id, "https://t.me/rsuserbotvoicemems/101", voice_note=True, reply_to=reply.id if reply else None)

#ᴇ ǫᴀʏᴅᴀɴ ᴋᴇʟᴅɪ ʙᴜ ʜᴀʀᴏᴍɪ ǫᴏᴄʜ ᴏɴᴀʜɢɴɪ sɪᴋᴀʏ ᴀᴅᴅ ʜᴀɴᴅʟᴇʀ ᴅᴀ ǫᴏᴛᴏ ʙᴏʀᴍɪ sᴀɴɢᴀ sᴏsᴋᴀ ʜᴀʀᴏᴍɪ 😹


with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(byqch)


with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(bmsdnx)

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(chqdrl)

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(hqtb)
	
with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(obmsn)

#ᴇ ǫᴀʏᴅᴀɴ ᴋᴇʟᴅɪ ʙᴜ ʜᴀʀᴏᴍɪ ǫᴏᴄʜ ᴏɴᴀʜɢɴɪ sɪᴋᴀʏ ᴀᴅᴅ ʜᴀɴᴅʟᴇʀ ᴅᴀ ǫᴏᴛᴏ ʙᴏʀᴍɪ sᴀɴɢᴀ sᴏsᴋᴀ ʜᴀʀᴏᴍɪ 😹


with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(ksikishmelar)



with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(dnxrek)


with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(sqnbosa)



with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(homqt)



with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(buninmal)



with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(drchqisen)


with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(drchqima)



with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(qndeyz)



with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(iyuqdrl)




with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(alo)


with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(nimagap)



with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(snxrm)




with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(ngjim)


with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(slmq)


with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(mangap)



with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(pnxg)


with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(ovdlb)


with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(sbchami)

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(edlb)
	
with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(voicemem)	