#Kodning Dasturchisi && manba  🤓 #Telegram @Rasulbekdev
#Insofingiz bolsa manba ni ochirmang🫠
from telethon import events
from plugins.client import client
import asyncio
from datetime import datetime, timezone, timedelta
from telethon.tl.functions.account import UpdateProfileRequest
from telethon.tl.functions.users import GetFullUserRequest
client=client

@events.register(events.NewMessage(pattern=r'\.timebioon'))
async def clockon(event):
    global enabled
    enabled = True
    await event.edit("😃 Bio soat qoyildi\n\nAgar Bio soatni ochirmoqchi bolsangiz\n\n```.timeBioOff - Soatni ochiradi```\n\nUserbotimizdan foydalanganingiz uchun rahmat")
    separator = "|"
    me = await client.get_me()
    me_chat = await client(GetFullUserRequest(me.id))
    current_bio = me_chat.full_user.about if me_chat.full_user.about else ""
    bio_parts = current_bio.split(separator)
    current_static_bio = bio_parts[0] if bio_parts else ""
    current_dynamic_bio = bio_parts[1] if len(bio_parts) > 1 else ""
    file_path="biotext.py"
    data = f'bio = "{current_static_bio}"'
    with open(file_path, "w") as file:
        file.write(data)

    while enabled:
    	uzbek_tz = timezone(timedelta(hours=5))
    	now = datetime.now(uzbek_tz)
    	nickname_hour = now.strftime("%H:%M")
    	await client(UpdateProfileRequest(about=f"{current_static_bio} {separator} {nickname_hour}"))
    	await asyncio.sleep(30)

@events.register(events.NewMessage(pattern=r'\.timebiooff'))
async def clockoff(event):
    global enabled
    if enabled:
        enabled = False
        await event.edit('bio soat ochirildi 🫠')
        from biotext import bio
        bio = bio
        await client(UpdateProfileRequest(about=bio))
    else:
        await event.edit('Soat allaqachon ochirlgan 🫤')




@events.register(events.NewMessage(pattern=r'\.timeon'))
async def clockBioOn(event):
    global enabledBio
    enabledBio = True
    await event.edit("😃 Profilingizga soat qoyildi\n\nAgar profilingizdagi soatni ochirmoqchi bolsangiz\n\n```.timeOff - Soatni ochiradi```\n\nUserbotimizdan foydalanganingiz uchun rahmat")
    separator = "|"
    while enabledBio:
        uzbek_tz = timezone(timedelta(hours=5))
        now = datetime.now(uzbek_tz)

        nickname_hour = now.strftime("%H:%M")

        await client(UpdateProfileRequest(last_name=nickname_hour))
        print(f"Soat Vaqt yangilandi :  {nickname_hour}")
        await asyncio.sleep(30)

@events.register(events.NewMessage(pattern=r'\.timeoff'))
async def clockBioOff(event):
    global enabledBio
    if enabledBio:
        enabledBio = False
        await event.edit('Profilingizdagi soat ochirildi 🫠')
        await client(UpdateProfileRequest(last_name=""))
    else:
        await event.edit('Soat allaqachon ochirlgan 🫤')

#ADD handler | Ha uka kod yoqtimi 😂 nega kodga qarab turibsan oldin kod yozishni organib kel ble 

#ADD handler | Ha uka kod yoqtimi 😂 nega kodga qarab turibsan oldin kod yozishni organib kel ble 

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(clockoff)

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(clockon)

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(clockBioOff)

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(clockBioOn)
