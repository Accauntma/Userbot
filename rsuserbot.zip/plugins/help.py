from telethon import TelegramClient, events
import os
import time
import plugins.client
client = plugins.client.client




@events.register(events.NewMessage(outgoing=True, pattern='.ahelp'))
async def ahelp(event):
    try:
        await event.edit("""```\nᴡᴇʟᴄᴏᴍᴇ ᴛᴏ ʜᴇʟᴘ ᴍᴇɴᴜ 🌒```\n```⚙ᴘʟᴜɢɪɴs ```\n`.timeon` `.timebioon` `.art`<text> `.number`<number>\n```🌘 ᴀɴɪᴍᴀᴛɪᴏɴs```\n```🔒 ᴇɴᴄᴏᴅᴇʀs```\n```👮🏻‍♀ ᴍᴏᴅᴇs```\n```⚡️ ғᴀᴋᴇ ᴀᴄᴛɪᴏɴs ```\n```📥 ᴅᴏᴡɴʟᴏᴀᴅᴇʀs```\n```🎲 ɢᴀᴍᴇs ```\n\nᴍᴏʀᴇ ᴘʟᴜɢɪɴs `.help`""")
    except Exception as e:
    	await event.edit(f"ᴇʀʀᴏʀ: <{e}>")




@events.register(events.NewMessage(outgoing=True, pattern='.plugins'))
async def plugins(event):
    try:
        await event.edit("""```⚙ ᴘʟᴜɢɪɴs ᴄᴏᴍᴍᴀɴᴅs ```

▫️ᴀʟɪᴠᴇ ᴜsᴇʀʙᴏᴛ `.alive` 
▫️ᴜsᴇʀ ɪɴғᴏ`.userinfo` 
▫️ɪᴘ ᴛʀᴀᴄᴇ `.iptrace <ip adres>` 
▫️ᴡᴇʙsᴄʀᴇᴇɴ`.webscreen <url>` 
▫️ᴛʀᴀɴsʟᴀᴛᴏʀ `.trns <code>`
▫️sᴀᴠᴇ ɪᴍᴀɢᴇs `.rcd <repliy>`
▫️ᴄʜᴀᴛ ɢᴘᴛ `.gpt <your question>`
▫️ᴍᴜᴛᴇ `.mute m/h/d/y`
▫️ᴘɪɴ ᴍᴇssᴀɢᴇ `.pin <reply>`
▫️ɢᴏᴏɢʟᴇ ᴛᴛs `.tts <code>`
▫️ᴠᴏɪᴄᴇ ᴍᴇᴍs `.voicemem`
▫️ʜᴀʀғɢᴀ ᴠɪᴅᴇᴏ `.hvideo`
▫️ʟᴇxɪᴀʀᴛ `.art <text>`
▫️ᴛᴇxᴛ ᴛᴏ ᴜᴢ sᴘᴇᴇᴄʜ `.speech`
▫️ʙɪᴏ ᴄʟᴏᴄᴋ `.aboutclock <time>`
▫️ᴛɪᴍᴇʀ `.timer <time>`
▫️ʀᴏᴄᴏᴠᴇʀʏ ɢʀᴏᴜᴘ ᴍᴇsᴀᴀɢᴇ `.rgm`
▫️sᴀᴠᴇ ᴄᴏɴᴛᴇɴᴛ ʀsᴛ ɢʀᴏᴜᴘ `.rts`
▫️ɴɪᴄᴋɴᴀᴍᴇ ᴄʟᴏᴄᴋ `.clocku <time>`
▫️sᴇᴀʀᴄʜ ᴅᴇʟᴇᴛᴇᴅ ᴀᴋᴀᴜɴᴛ `.sda`
▫️ʀᴇᴍᴏᴠᴇ ᴅᴇʟᴇᴛᴇᴅ ᴀᴋᴀᴜɴᴛ `.rda`
▫️ᴛʏᴘᴇ ᴍᴇssᴀɢᴇ `.type <text>`
▫️ɴᴜᴍʙᴇʀs `.numbers <count>`
▫️ғʟᴏᴏᴅ ᴍᴇssᴀɢᴇ `.flood`
▫️ᴄʜᴀᴛ ɪɴғᴏ `.chatinfo`
▫️ᴡɪᴋɪᴘᴇᴅɪᴀ `.wikipedia`
▫️ᴄᴀʟᴄᴜʟᴀᴛᴏʀ `.calc +-*/`
▫️ɴᴜᴍʙᴇʀ ɪɴғᴏ `.numinfo <reply>`
▫️ɢᴇᴛ ʜᴛᴍʟ `.htmldown <ᴡᴇʙ ᴜʀʟ>`
▫️ᴜʀʟ sʜᴏʀᴛᴇɴᴇʀ `.shorturl <url>`
▫️ᴛᴇᴘᴍᴇʀᴀᴛᴜʀᴇ ᴡᴛᴇᴀᴛʜ `wth <RG>`
▫️ᴅᴇʟ ᴍᴇssᴀɢᴇ `.delmsg <count>`
▫️ᴅᴇʟʟ ᴀʟʟ ᴘʀᴏғɪʟᴇ ᴘɪᴄ `.rmpic`
▫️ɢɪᴛʜᴜʙ ɪɴғᴏ `.gitinfo <name>`
▫️ᴄᴜʀʀᴇɴᴄʏ `.currency`
▫️ᴘʀᴇᴍɪᴜᴍ sᴛɪᴄᴋᴇʀs `.prstick`
▫️ʙᴀᴄᴋʀᴏᴜɴᴅ ʀᴇᴍᴏᴠᴇʀ `.bgrm 
▫️sᴀᴠᴇ ᴄᴏɴᴛᴇɴᴛ `.svcn <url>`
▫️ᴄᴏʟᴏʀ ʏᴏᴜʀ ᴄᴏᴅᴇ `.clcode <code>`""")
    except Exception as e:
    	await event.edit(f"ᴇʀʀᴏʀ: <{e}>")


		
@events.register(events.NewMessage(outgoing=True, pattern='.animations'))
async def animations(event):
    try:
        await event.edit("""🌘 ᴀɴɪᴍᴀᴛɪᴏɴ ᴄᴏᴍᴀɴᴅs

🪄 ᴀɴɪᴍᴀᴛᴏɴs `40`

◾️ sɴᴀᴋᴇ `.snake` 
◾️ ɴᴏᴛʜᴀᴘᴘʏ `.nothappy` 
◾️ ʜᴇᴀʀᴛs `.heart` 
◾️ ʟᴏᴏʟ `.lul` 
◾️ ᴄʟᴏᴡɴ `.clown` 
◾️ ᴄᴀɴᴅʏ `.candy`
◾️ ᴄʟᴏᴄᴋ `.clock`
◾️ ᴍᴜᴀʜ `.muah`
◾️ ᴇᴀʀᴛʜ `.earth`
◾️ ᴍᴏᴏɴ `.moon`
◾️ sᴍᴏᴏɴ `.smoon`
◾️ ᴛᴍᴏᴏɴ `.tmoon`
◾️ ᴄʏᴍɴᴀsᴛɪᴄ `.gym`
◾️ sᴇxʏ `.sexy`
◾️ ᴍᴀɢɪᴄ `.magic`
◾️ ᴘᴏʟɪᴄᴇ `.police`
◾️ ᴘʟᴀɴᴇ `.plane`
◾️ ғᴜᴄᴋ `.fuck`
◾️ ᴄᴏʟᴏʀ ʙᴏxs `.boxs`
◾️ ᴄʟᴏʟ `.clol`
◾️ ʙᴜᴛᴛᴇʀғʟʏ `.butter`
◾️ ᴏᴅʀᴀ `.odra`
◾️ ғʟᴇᴀᴠᴇᴍᴇ `.fleaveme`
◾️ ʟᴏᴠᴇᴜ `.loveu`
◾️ ᴊɪᴏ `.jio`
◾️ sᴏʟᴀʀsʏsᴛᴇᴍ `.solarsystem`
◾️ ʀᴀɪɴɪɴɢ `.raining`
◾️ sᴍɪʟᴇ `.smile`
◾️ sɴᴏᴡ `.snow`
◾️ ʜᴜɪ `.hui`
◾️ ᴛᴇxᴛ ᴛᴏ ʜᴇᴀʀᴛs `.emoji <text>`
◾️ ʟᴏᴠᴇʟʏ `.lovely`
◾️ ᴛᴜʀᴛʟᴇ `.turtle`
◾️ ᴅɪɴᴏ `.dino`
◾️ ʟᴏᴀᴅɪɴɢ `.loading`
◾️ ᴍᴀɢɪᴄ ᴘʀᴇᴍɪᴜᴍ `.pmagic`
◾️ ᴘᴏʏᴇᴢᴅ `.chukchuk`
◾️ ʟᴏᴠᴇ `.vlove`
◾️ ᴊᴜᴍᴀ `.juma`
◾️ ɴᴀʀᴜᴛᴏ `.naruto`""")
    except Exception as e:
    	await event.edit(f"ᴇʀʀᴏʀ: <{e}>")




@events.register(events.NewMessage(outgoing=True, pattern='.fakeactions'))
async def actions(event):
    try:
        await event.edit("""⚡️ ғᴀᴋᴇ ᴀᴄᴛɪᴏɴs ᴄᴏᴍᴍᴀɴᴅs

⚡️ ᴀᴄᴛɪᴏɴs `11`

◼️ ᴛʏᴘᴇ ғᴀᴋᴇ `.faketype <time>`
◼️ ᴠᴏɪᴄᴇ ғᴀᴋᴇ `.fakevoice <time>`
◼️ ɢᴀᴍᴇ ғᴀᴋᴇ `.fakegame <time>`
◼️ ᴘʜᴏᴛᴏ ғᴀᴋᴇ `.fakephoto <time>`
◼️ ᴠɪᴅᴇᴏ ғᴀᴋᴇ `.fakevideo <time>`
◼️ ғɪʟᴇ  ғᴀᴋᴇ `.fakedcmt <time>`
◼️ ʀᴏᴜɴᴅ ғᴀᴋᴇ `.fakeround <time>`
◼️ sᴛɪᴄᴋᴇʀ ғᴀᴋᴇ `.fakestick <time>`
◼️ ᴄᴏɴᴛᴀᴄᴛ ғᴀᴋᴇ `.fakecon <time>`
◼️ ʟᴏᴄᴀᴛɪᴏɴ ғᴀᴋᴇ `.fakeloc <time>`
◼️ ʀᴇᴀᴅ && ᴏɴʟɪɴᴇ 24/7 `.online`\n\n◼️ɪғ ʏᴏᴜ sᴇɴᴅ `.online` ᴀ sᴇᴄᴏɴᴅ ᴛɪᴍᴇ, ᴛʜᴇ ʀᴇᴀᴅ & ᴏɴʟɪɴᴇ ᴍᴏᴅᴇ ᴡɪʟʟ sᴛᴏᴘ ⚡️""")
    except Exception as e:
    	await event.edit(f"ᴇʀʀᴏʀ: <{e}>")



@events.register(events.NewMessage(outgoing=True, pattern='.modes'))
async def modes(event):
    try:
        await event.edit("""👮🏻‍♀ ᴍᴏᴅᴇs ᴄᴏᴍᴍᴀɴᴅs

👮🏻‍♀ ᴍᴏᴅᴇs `3`

ʙʟᴏᴄᴋ ᴍᴏᴅᴇ 🚷

◽️ʙʟᴏᴄᴋ ᴍᴏᴅᴇ ᴏɴ `.blockon`
◽️ʙʟᴏᴄᴋ ᴍᴏᴅᴇ ᴏғғ `.blockoff`
◽️ᴄʜᴇᴄᴋ ʙʟᴏᴄᴋ ᴍᴏᴅᴇ `.blockinfo`
◽️ᴄᴏɴғɪʀᴍᴀᴛɪᴏɴ `.pa`
◽️ʀᴇᴍᴏᴠᴇ ғʀᴏᴍ ᴀᴘᴘʀᴏᴠᴇᴅ `.pda`
◽️ʟɪsᴛ ᴏғ ᴠᴇʀɪғɪᴇᴅ ᴜsᴇʀs `.tlist`

ᴀғᴋ ᴍᴏᴅᴇ 👤

◽️ᴏɴ ᴀғᴋ ᴍᴏᴅᴇ `.afkon`
◽️ᴏғғ ᴀғᴋ ᴍᴏᴅᴇ `.afkoff`
◽️ᴀғᴋ sᴛᴀᴛᴜs ᴄʜᴇᴄᴋ `.afkinfo`

♻️ ᴇᴄʜᴏ ᴍᴏᴅᴇ

◽️ᴇᴄʜᴏ ᴍᴏᴅᴇ ᴏɴ `.echo on`
◽️ᴇᴄʜᴏ ᴍᴏᴅᴇ ᴏғғ `.echo off`
""")
    except Exception as e:
    	await event.edit(f"ᴇʀʀᴏʀ: <{e}>")



@events.register(events.NewMessage(outgoing=True, pattern='.encoders'))
async def encoder(event):
    try:
        await event.edit("""🔒 ᴇɴᴄᴏᴅᴇʀ ᴄᴏᴍᴍᴀɴᴅs

🔒 ᴇɴᴄᴏᴅᴇʀs `21`

◾️ ᴢʟɪʙ ᴇɴᴄᴏᴅᴇʀ `.zlib <text>`
◾️ ᴢʟɪʙ ᴅᴇᴄᴏᴅᴇʀ `.unzlib`
◾️ ᴘɪᴄᴋʟᴇ ᴇɴᴄᴏᴅᴇʀ `.pickle <text>`
◾️ ᴘɪᴄᴋʟᴇ ᴅᴇᴄᴏᴅᴇʀ `.unpickle`
◾️ ᴄᴏᴍᴘɪʟᴇʀ ᴍ `.marshcom <text>`
◾️ ᴇɴᴄᴏᴅᴇʀ ᴍ`.marshal <text>`
◾️ ᴇɴᴄᴏᴅᴇ ʙɪɴᴀʀʏ `.binary <text>`
◾️ ᴅᴇᴄᴏᴅᴇ ʙɪɴᴀʀʏ `.binaryde`
◾️ ᴇɴᴄᴏᴅᴇʀ ʙɪɴᴀsᴄɪɪ `.binascii`
◾️ ᴅᴇᴄᴏᴅᴇ ʙɪɴᴀsᴄɪɪ <ᴇɴᴄ ᴛᴇxᴛ>
◾️ ᴇɴᴄᴏᴅᴇ ʙᴀsᴇ85 `.base85 <text>`
◾️ ᴅᴇᴄᴏᴅᴇ ʙᴀsᴇ85 `.base85de`
◾️ ᴇɴᴄᴏᴅᴇ ʙᴀsᴇ64 `.base64 <text>`
◾️ ᴅᴇᴄᴏᴅᴇ ʙᴀsᴇ64 `.base64de`
◾️ ᴇɴᴄᴏᴅᴇ ʙᴀsᴇ32 `.base32 <text>`
◾️ ᴅᴇᴄᴏᴅᴇ ʙᴀsᴇ32 `.base32de`
◾️ ᴇɴᴄᴏᴅᴇ ʙᴀsᴇ16 `.base16 <text>`
◾️ ᴅᴇᴄᴏᴅᴇ ʙᴀsᴇ16 `.base16`
◾️ ᴇɴᴄᴏᴅᴇ ʜᴇx `.hex <text>`
◾️ ᴅᴇᴄᴏᴅᴇ ʜᴇx `.unhex`
◾️ sᴇᴄʀᴇᴛ ᴇɴᴄᴏᴅᴇʀ `.secen <text>`""")
    except Exception as e:
    	await event.edit(f"ᴇʀʀᴏʀ: <{e}>")


@events.register(events.NewMessage(outgoing=True, pattern='.downloaders'))
async def downloaders(event):
    try:
        await event.edit("""🔒 ᴇɴᴄᴏᴅᴇʀ ᴄᴏᴍᴍᴀɴᴅs

🔒 ᴇɴᴄᴏᴅᴇʀs `20`

◾️ ᴢʟɪʙ ᴇɴᴄᴏᴅᴇʀ `.zlib <text>`
◾️ ᴢʟɪʙ ᴅᴇᴄᴏᴅᴇʀ `.unzlib`
◾️ ᴘɪᴄᴋʟᴇ ᴇɴᴄᴏᴅᴇʀ `.pickle <text>`
◾️ ᴘɪᴄᴋʟᴇ ᴅᴇᴄᴏᴅᴇʀ `.unpickle`
◾️ ᴄᴏᴍᴘɪʟᴇʀ ᴍ `.marshcom <text>`
◾️ ᴇɴᴄᴏᴅᴇʀ ᴍ`.marshal <text>`
◾️ ᴇɴᴄᴏᴅᴇ ʙɪɴᴀʀʏ `.binary <text>`
◾️ ᴅᴇᴄᴏᴅᴇ ʙɪɴᴀʀʏ `.binaryde`
◾️ ᴇɴᴄᴏᴅᴇʀ ʙɪɴᴀsᴄɪɪ `.binascii`
◾️ ᴅᴇᴄᴏᴅᴇ ʙɪɴᴀsᴄɪɪ <ᴇɴᴄ ᴛᴇxᴛ>
◾️ ᴇɴᴄᴏᴅᴇ ʙᴀsᴇ85 `.base85 <text>`
◾️ ᴅᴇᴄᴏᴅᴇ ʙᴀsᴇ85 `.base85de`
◾️ ᴇɴᴄᴏᴅᴇ ʙᴀsᴇ64 `.base64 <text>`
◾️ ᴅᴇᴄᴏᴅᴇ ʙᴀsᴇ64 `.base64de`
◾️ ᴇɴᴄᴏᴅᴇ ʙᴀsᴇ32 `.base32 <text>`
◾️ ᴅᴇᴄᴏᴅᴇ ʙᴀsᴇ32 `.base32de`
◾️ ᴇɴᴄᴏᴅᴇ ʙᴀsᴇ16 `.base16 <text>`
◾️ ᴅᴇᴄᴏᴅᴇ ʙᴀsᴇ16 `.base16`
◾️ ᴇɴᴄᴏᴅᴇ ʜᴇx `.hex <text>`
◾️ ᴅᴇᴄᴏᴅᴇ ʜᴇx `.unhex`""")
    except Exception as e:
    	await event.edit(f"ᴇʀʀᴏʀ: <{e}>")



@events.register(events.NewMessage(outgoing=True, pattern='.games'))
async def games(event):
    try:
        await event.edit("""🎲 ɢᴀᴍᴇs ᴄᴏᴍᴍᴀɴᴅs 

🎲 ɢᴀᴍᴇs `9`

◾ᴛɪᴄ ᴛᴀᴄ ᴛᴏᴇ `.tic-tac-toe`
◾ᴛɪᴄ ᴛᴀᴄ ғᴏᴜʀ `.tic-tac-four`
◾ᴇʟᴇᴘʜᴀɴᴛ xᴏ `.elephant-XO`
◾ᴄᴏɴɴᴇᴄᴛ ғᴏᴜʀ `.connect-four`
◾ᴄʜᴇᴄᴋᴇʀs `.checkers`
◾ᴘᴏᴏʟ ᴄʜᴇᴄᴋᴇʀs `.pool-checkers`
◾ʀᴜssɪᴀɴ ʀᴏᴜʟᴇᴛᴛᴇ `.russian-roulette`
◾ʀᴏᴄᴋ ᴘᴀᴘᴇʀ `.rock-paper`
◾ʀᴏᴄᴋ ᴘᴀᴘᴇʀ ʟɪᴢᴀʀᴅ `.lizard-rock-paper`
""")
    except Exception as e:
    	await event.edit(f"ᴇʀʀᴏʀ: <{e}>")





with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(games)

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(modes)
	
with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(actions)
	
with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(downloaders)

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(ahelp)
	
with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(animations)
	
with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(plugins)

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(encoder)															