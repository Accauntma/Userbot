from telethon import events
import requests
import xml.etree.ElementTree as ET
from plugins.client import client

client=client

async def rubles_to_uzb(money):
    po = 0
    response = requests.get("http://cbu.uz/uzc/arkhiv-kursov-valyut/xml/")
    xml = response.content
    m = ET.fromstring(xml)
    for val in m:
        if val.find('Ccy').text == f'{money}':
            po = float(val.find('Rate').text)
            p = po
    tg_money = 1 * p
    return tg_money

@events.register(events.NewMessage(outgoing=True, pattern='\.kurs'))
async def currency(event):
    await event.edit("•ᴘʟɪsᴇ ᴡᴀɪᴛ  ... (1-5 ᴍɪɴᴜᴛᴇ)")    
    money = ['RUB', 'USD', 'EUR','KGS','KZT']
    exchange_rates = []
    for x in money:
        exchange_rate = await rubles_to_uzb(x)
        exchange_rates.append(exchange_rate)
    message_text = (f"How much is the money of 28 countries in Uzbek 🇺🇿 som 💸 💱\n\n1 EUR 🇪🇺 - {exchange_rates[3]} So'm\n"
                    f"1 RUB 🇷🇺 - {exchange_rates[1]} So'm\n"
                    f"1 USD 🇺🇸 - {exchange_rates[2]} So'm\n"
                    f"1 KGS 🇰🇬 - {exchange_rates[4]} So'm\n"
                    f"1 KZT 🇰🇿 - {exchange_rates[5]} So'm\n")
    
    
    await event.edit(message_text)


with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(currency)