from telethon import TelegramClient, events
from telethon.tl.functions.users import GetFullUserRequest
import plugins.client
import os
import time

client = plugins.client.client

@events.register(events.NewMessage(outgoing=True, pattern='\.alive'))
async def alive(noob_py):
		client = noob_py.client
		me = await client.get_me()
		username = me.username
		Rs_Userbot = "https://telegra.ph/file/161e73a1797b86ceba2cb.jpg"
		await noob_py.edit("ᴡᴀɪᴛ...")
		time.sleep(0.5)
		await noob_py.respond("""👤 ᴛɢ ᴜsᴇʀɴᴀᴍᴇ » @{}

🖤 ɴᴀᴍᴇ » ʀs ᴜsᴇʀʙᴏᴛ

⚙ ᴠᴇʀsɪᴏɴ » 1.0.0

🌐 ɪɴsᴛᴀʟʟ ɴᴏᴡ » @RsDeveloperKG

© ʀᴀsᴜʟʙᴇᴋᴅᴇᴠ""".format(username, ' '), file=Rs_Userbot)
		await noob_py.message.delete()