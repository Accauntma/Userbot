from telethon import TelegramClient, events
import requests
import asyncio
import xml.etree.ElementTree as ET
from plugins.client import client

client=client

@events.register(events.NewMessage(outgoing=True, pattern='.wiki'))
async def wikipedia(event):
    await event.edit("• ᴡɪᴋɪᴘᴇᴅɪᴀ sᴇᴛ ʟᴀɴɢ •\n\n🇺🇿 ᴡɪᴋɪᴘᴇᴅɪᴀ ᴜᴢ » .wikiuz <ᴛᴇxᴛ>\n🇺🇸 ᴡɪᴋɪᴘᴇᴅɪᴀ ᴇɴ » .wikien <ᴛᴇxᴛ>\n🇷🇺 ᴡɪᴋɪᴘᴇᴅɪᴀ ʀᴜ » .wikiru < ᴛᴇxᴛ>")


import wikipediaapi

wiki_ru = wikipediaapi.Wikipedia(
    language='ru',
    extract_format=wikipediaapi.ExtractFormat.WIKI,
    user_agent='Your User Agent'
)


wiki_uz = wikipediaapi.Wikipedia(
    language='uz',
    extract_format=wikipediaapi.ExtractFormat.WIKI,
    user_agent='Your User Agent'
)



wiki_en = wikipediaapi.Wikipedia(
    language='en',
    extract_format=wikipediaapi.ExtractFormat.WIKI,
    user_agent='Your User Agent'
)



@events.register(events.NewMessage(outgoing=True, pattern='.wikiuz'))
async def wikiuz(event):
    query = event.raw_text[7:]
    if len(query) > 0:
        await event.edit("•ɪʟᴛɪᴍᴏs ᴋᴜᴛɪʙ ᴛᴜʀɪɴɢ...")
        page = wiki_uz.page(query)
        if page.exists():
            summary = page.summary[:280] + '...' if len(page.summary) > 280 else page.summary
            response = f"{page.title}\n{summary}\nǫᴏsʜɪᴍᴄʜᴀ ᴋᴏᴘʀᴏǫ ᴍᴀʟᴜᴍᴏᴛ ᴜᴄʜᴜɴ »  {page.fullurl}"
        else:
            response = "ᴋᴇᴄʜɪʀᴀsɪᴢ ᴡɪᴋɪᴘᴇᴅɪᴀᴅᴀ ʙᴜɴᴅᴀʏ ᴍᴀʟᴜᴍᴏᴛ ᴍᴀᴠᴊᴜᴅ ᴇᴍᴀs  ):"
    else:
        response = "ᴡɪᴋɪᴘᴇᴅɪᴀᴅᴀɴ ғᴏʏᴅᴀʟᴀɴɪsʜ ᴜᴄʜᴜʙ ᴍᴀɴᴀʙᴜɴᴅᴀʏ ғᴏʏᴅᴀʟᴀɴɪɴɢ .wikiuz <sᴀᴠᴏʟ>"
    await event.edit(response)




@events.register(events.NewMessage(outgoing=True, pattern='.wikien'))
async def wikien(event):
    query = event.raw_text[7:]
    if len(query) > 0:
        await event.edit("ᴘʟɪsᴇ ᴡᴀɪᴛ...")
    page = wiki_en.page(query)
    if page.exists():
        summary = page.summary[:280] + '...' if len(page.summary) > 280 else page.summary
        response = f"{page.title}\n{summary}\nғᴏʀ ᴍᴏʀᴇ ɪɴғᴏʀᴍᴀᴛɪᴏɴ » {page.fullurl}"
    else:
        response = "sᴏʀʀʏ, ɪ ᴄᴏᴜʟᴅɴ'ᴛ ғɪɴᴅ ᴀɴʏ ɪɴғᴏʀᴍᴀᴛɪᴏɴ ᴏɴ ᴛʜɪs ᴛᴏᴘɪᴄ ):"
    await event.edit(response)




@events.register(events.NewMessage(outgoing=True, pattern='.wikiru'))
async def wikiru(event):
    query = event.raw_text[7:]
    if len(query) > 0:
        await event.edit("•Пожалуйста, подождите...")
        page = wiki_ru.page(query)
        if page.exists():
            summary = page.summary[:280] + '...' if len(page.summary) > 280 else page.summary
            response = f"{page.title}\n{summary}\nДля получения дополнительной информации: {page.fullurl}"
        else:
            response = "Извините, я не смог найти информацию по этой теме ):"
    else:
        response = "Пожалуйста, укажите слово для поиска на Википедии. Пример: .wikiru <слово>"
    await event.edit(response)





with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(wikipedia)

with client as Rs_Userbot:
    Rs_Userbot.add_event_handler(wikiru)

with client as Rs_Userbot:
    Rs_Userbot.add_event_handler(wikien)

with client as Rs_Userbot:
    Rs_Userbot.add_event_handler(wikiuz)