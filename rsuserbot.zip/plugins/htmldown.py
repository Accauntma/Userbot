from telethon import events
import asyncio
import os
import requests,time
from plugins.client import client

client=client

@events.register(events.NewMessage(pattern='.htmldown'))
async def htmldownloader(event):
    
    website_url = event.message.text.split(' ')[1]
    
    
    response = requests.get(website_url)
    await event.edit("⚙ ᴘʟɪsᴇ ᴡᴀɪᴛ.")
    time.sleep(1)
    await event.edit("⚙ ᴘʟɪsᴇ ᴡᴀɪᴛ..")
    time.sleep(1)
    await event.edit("⚙ ᴘʟɪsᴇ ᴡᴀɪᴛ...")
    
    
    with open('ZetUserbot.html', 'w', encoding='utf-8') as f:
        f.write(response.text)
        await event.delete()
    
    
    
    await client.send_file(event.chat_id, 'ZetUserbot.html',caption=f"🌐 ᴡᴇʙsɪᴛᴇ {website_url}")
    
    
    os.remove('Rs-Userbot.html')
    
with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(htmldownloader)