from telethon import TelegramClient, events
import marshal
import zlib
import pickle
import binascii
import base64
import plugins.client

client=plugins.client.client


"""Binary"""

@events.register(events.NewMessage(outgoing=True,pattern=r"\.binary\s+(.*)"))
async def binary(event):
    text = event.pattern_match.group(1)
    encoded = ''.join(format(ord(c), '08b') for c in text)
    await event.edit(f"ʙɪɴᴀʀʏ`{encoded}`")

@events.register(events.NewMessage(outgoing=True,pattern=r"\.binaryde\s+(.*)"))
async def binaryde(event):
    text = event.pattern_match.group(1)
    decoded = ''.join(chr(int(text[i:i+8], 2)) for i in range(0, len(text), 8))
    await event.edit(f"{decoded}")

"""Base85"""

@events.register(events.NewMessage(outgoing=True,pattern=r'\.base85 (\S+)'))
async def encode_base85(event):
    text_to_encode = event.pattern_match.group(1).encode('utf-8')
    encoded_text = base64.b85encode(text_to_encode).decode('utf-8')
    await event.edit("Base85 `"+encoded_text+"`")


@events.register(events.NewMessage(outgoing=True,pattern=r'\.base85de (\S+)'))
async def base85de(event):
    text_to_decode = event.pattern_match.group(1).encode('utf-8')
    decoded_text = base64.b85decode(text_to_decode).decode('utf-8')
    await event.edit("`"+decoded_text+"`")


with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(binary)

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(base85de)


with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(encode_base85)	

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(binaryde)	
