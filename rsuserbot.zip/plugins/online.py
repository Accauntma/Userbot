from telethon import TelegramClient, events
import asyncio
import time
import random
from plugins.client import client

client=client
#chat_id = 6881640288
@events.register(events.NewMessage)
async def watcher(event):
    if online_status:
        await event.client.send_read_acknowledge(user_id = 6881640288)

online_status = False

@events.register(events.NewMessage(outgoing=True,pattern='.online'))
async def online_toggle(event):
    global online_status
    if not online_status:
        online_status = True
        await event.edit('🟢 Online mod ishga tushdi endi accountingizga kimdur biror soz yozsa accountingiz birdaniga online rejimiga tushadi va kelgan habarlarni avtomatik oqiydi')
        while online_status:
            print('Online mod yangilandi 🖤')
            await asyncio.sleep(1000)
            await event.delete()
    else:
        online_status = False
        await event.edit('🔴 Online mod ochirldi endi accountingiz kimdur yozsa avto online bolmaydi va habarlarham oqilmaydi ')

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(online_toggle)
	
with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(watcher)                
#with client as Watcher:
#	Watcher.add_event_handler(watcher)
#with client as Online_toggle:
#	Online_toggle.add_event_handler(online_toggle)
