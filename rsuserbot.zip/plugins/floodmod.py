#Kodning Dasturchisi && manba  🤓 #Telegram @Rasulbekdev
#Insofingiz bolsa manba ni ochirmang🫠

from telethon import events, TelegramClient
from plugins.client import client
import asyncio
import time

client=client

@events.register(events.NewMessage(pattern=r'.flood ?(.*)'))
async def floodon(e):
    global enabled
    enabled = True
    try:
    				while enabled:
    					args = e.text.split(" ", 3)
    					Rs = float(args[1])
    					count = int(args[2])
    					msg = str(args[3])
#    				except BaseException:
    						#return await e.edit(f"**.flood <ғʟᴏᴏᴅ ᴛɪᴍᴇ> <ᴄᴏᴜɴᴛ> <ᴛᴇxᴛ>**")
    await e.delete()
    						try:
    						  for i in range(count):
    						  	await e.respond(msg)
    						  	await asyncio.sleep(Rs)
    						  	except Exception as u:
    						  		await e.respond(f"ᴇʀʀᴏʀ » `{u}`")
    						  		except Exception as e:
    						  			await event.edit(f"Flood qilishda hatolikga yol qoydingiz 🤡\n\n```.flood soz vaqt masalan - .flood userbot 10 har bitta habarni har 10 sekond ichida yuboradi ```")

@events.register(events.NewMessage(pattern=r'\.offlood'))
async def floodoff(event):
    global enabled
    if enabled:
        enabled = False
        await event.edit('Habarni flood qiliuvchi funksiya ochirildi ;)')
    else:
        await event.edit('Bu funnksiya allaqachon ochirilgan 🫤')

#ADD handler | Ha uka kod yoqtimi 😂 nega kodga qarab turibsan oldin kod yozishni organib kel ble 


with client as clock:
	clock.add_event_handler(floodoff)
	clock.add_event_handler(floodon)