from telethon import events
from datetime import datetime
from time import sleep
from telethon.tl.functions.users import GetFullUserRequest


afkmode = set([])

@events.register(events.NewMessage(outgoing=True, pattern=r'\.afkon'))
async def runafkon(event):
    await event.edit("ʟᴏᴀᴅɪɴɢ...")
    sleep(2)
    await event.delete()
    messagelocation = event.to_id
    getreason = event.message.raw_text.splitlines()
    replacecmd = getreason[0].replace(".afkon ", "")
    runafkon.afkreason = replacecmd.splitlines()
    runafkon.reason = runafkon.afkreason[0]
    try:
        if afkmode:
            if "off" in afkmode:
                afkmode.remove("off")
        afkmodeon = "on"
        if afkmodeon in afkmode:
            await event.client.send_message(messagelocation, "ᴀғᴋ ᴍᴏᴅᴇ ʜᴀs ᴀʟʀᴇᴀᴅʏ ʙᴇᴇɴ ᴀᴄᴛɪᴠᴀᴛᴇᴅ ᴀɴᴅ ʏᴏᴜʀ ᴅᴀᴛᴀ ʜᴀs ʙᴇᴇɴ ᴄᴏᴍᴘᴜʟsᴏʀɪʟʏ ᴜᴘᴅᴀᴛᴇᴅ 🖤...")
        else:
            afkmode.add(afkmodeon)
            runafkon.start = datetime.now()
            await event.client.send_message(messagelocation, "ᴀғᴋ ᴍᴏᴅᴇ ɪs sᴛᴀʀᴛᴇᴅ 🖤")
    except:
        pass

@events.register(events.NewMessage(outgoing=True, pattern=r'\.afkoff'))
async def runafkoff(event):
    await event.edit("ʟᴏᴀᴅɪɴɢ...")
    sleep(2)
    await event.delete()
    messagelocation = event.to_id
    try:
        afkmodeoff = "off"
        if "on" in afkmode:
            afkmode.remove("on")
            runafkon.afkreason.clear()
        if afkmodeoff in afkmode:
            await event.client.send_message(messagelocation, "ᴀғᴋ ᴍᴏᴅᴇ ɪs ᴀʟʀᴇᴀᴅʏ ᴅɪsᴀʙʟᴇᴅ 🖤")
        else:
            afkmode.add(afkmodeoff)
            await event.client.send_message(messagelocation, "ᴀғᴋ ᴍᴏᴅᴇ ɪs ᴏғ 🖤")
    except:
        pass

@events.register(events.NewMessage(outgoing=True, pattern=r'\.afkinfo'))
async def runafkstatus(event):
    await event.edit("ʟᴏᴀᴅɪɴɢ...")
    sleep(2)
    await event.delete()
    messagelocation = event.to_id
    try:
        statusinformation = []
        if afkmode:
            for details in afkmode:
                statusinformation.append(details)
            convertdata = "\n".join(statusinformation)
            await event.client.send_message(messagelocation, f"ᴀғᴋ sᴛᴀᴛᴜs » {convertdata.title()}")
        else:
            await event.client.send_message(messagelocation, "ᴀғᴋ ᴘʀᴏᴛᴇᴄᴛɪᴏɴ ɪs ᴅɪsᴀʙʟᴇᴅ ʙʏ ᴅᴇғᴀᴜʟᴛ 🙄")
    except:
        pass

@events.register(events.NewMessage)
async def runafk(event):
    if event.is_private:
        getridogramuserdetails = await event.client(GetFullUserRequest("me"))
        ridogramuser = getridogramuserdetails.users[0].id
        user = await event.get_chat()
        messagelocation = user.id
        replylocation = event.id
        senderinformation = await event.client(GetFullUserRequest(user.id))
        itisbot = senderinformation.users[0].bot
        isridogramuser = await event.get_sender()
        try:
            if "on" in afkmode:
                if itisbot == True:
                    pass
                else:
                    if user.id == ridogramuser:
                        pass
                    else:
                        if ridogramuser == isridogramuser.id:
                            pass
                        else:
                            end = datetime.now()
                            total = (end - runafkon.start)
                            countthetime = int(total.seconds)
                            sd = countthetime // (24 * 3600)
                            countthetime %= 24 * 3600
                            sh = countthetime // 3600
                            countthetime %= 3600
                            sm = countthetime // 60
                            countthetime %= 60
                            ss = countthetime
                            endtime = ""
                            if sd > 0:
                                endtime += f"{sd}d {sh}h {sm}m {ss}s"
                            elif sh > 0:
                                endtime += f"{sh}h {sm}m {ss}s"
                            else:
                                endtime += f"{sm}m {ss}s" if sm > 0 else f"{ss}s"
                            if runafkon.reason:
                                if ".afkon" in runafkon.reason:
                                    await event.client.send_message(messagelocation, f"""sᴏʀʀʏ, ᴅᴇᴀʀ {user.first_name}, ᴛʜᴇ ᴏᴡɴᴇʀ ᴏғ ᴛʜɪs ᴀᴄᴄᴏᴜɴᴛ ɪs ɴᴏᴛ ᴏɴʟɪɴᴇ ɴᴏᴡ
ɪ ᴀᴍ ʀᴇsᴘᴏɴsɪʙʟᴇ ғᴏʀ ᴛʜɪs ᴀᴄᴄᴏᴜɴᴛ 🖤

ɪғ ʏᴏᴜ ʜᴀᴠᴇ ᴀɴʏᴛʜɪɴɢ ᴛᴏ sᴀʏ ᴛᴏ ᴛʜᴇ ᴀᴄᴄᴏᴜɴᴛ ᴏᴡɴᴇʀ, ᴡʀɪᴛᴇ ɪᴛ ᴅᴏᴡɴ ᴀɴᴅ ʜᴇ ᴡɪʟʟ ᴅᴇғɪɴɪᴛᴇʟʏ ᴀɴsᴡᴇʀ ᴡʜᴇɴ ʜᴇ ɪs ᴏɴʟɪɴᴇ 🖤

ʟᴀsᴛ ᴏɴʟɪɴᴇ ᴛɪᴍᴇ » {endtime} ᴀɢᴏ""", reply_to=replylocation)
                                else:
                                    await event.client.send_message(messagelocation, f"""sᴏʀʀʏ, ᴅᴇᴀʀ {user.first_name}, ᴛʜᴇ ᴏᴡɴᴇʀ ᴏғ ᴛʜɪs ᴀᴄᴄᴏᴜɴᴛ ɪs ɴᴏᴛ ᴏɴʟɪɴᴇ ɴᴏᴡ
ɪ ᴀᴍ ʀᴇsᴘᴏɴsɪʙʟᴇ ғᴏʀ ᴛʜɪs ᴀᴄᴄᴏᴜɴᴛ 🖤

ɪғ ʏᴏᴜ ʜᴀᴠᴇ ᴀɴʏᴛʜɪɴɢ ᴛᴏ sᴀʏ ᴛᴏ ᴛʜᴇ ᴀᴄᴄᴏᴜɴᴛ ᴏᴡɴᴇʀ, ᴡʀɪᴛᴇ ɪᴛ ᴅᴏᴡɴ ᴀɴᴅ ʜᴇ ᴡɪʟʟ ᴅᴇғɪɴɪᴛᴇʟʏ ᴀɴsᴡᴇʀ ᴡʜᴇɴ ʜᴇ ɪs ᴏɴʟɪɴᴇ 🖤

ʟᴀsᴛ ᴏɴʟɪɴᴇ ᴛɪᴍᴇ » {endtime} ᴀɢᴏ""", reply_to=replylocation)
                            else:
                                await event.client.send_message(messagelocation, f"""sᴏʀʀʏ, ᴅᴇᴀʀ {user.first_name}, ᴛʜᴇ ᴏᴡɴᴇʀ ᴏғ ᴛʜɪs ᴀᴄᴄᴏᴜɴᴛ ɪs ɴᴏᴛ ᴏɴʟɪɴᴇ ɴᴏᴡ
ɪ ᴀᴍ ʀᴇsᴘᴏɴsɪʙʟᴇ ғᴏʀ ᴛʜɪs ᴀᴄᴄᴏᴜɴᴛ 🖤

ɪғ ʏᴏᴜ ʜᴀᴠᴇ ᴀɴʏᴛʜɪɴɢ ᴛᴏ sᴀʏ ᴛᴏ ᴛʜᴇ ᴀᴄᴄᴏᴜɴᴛ ᴏᴡɴᴇʀ, ᴡʀɪᴛᴇ ɪᴛ ᴅᴏᴡɴ ᴀɴᴅ ʜᴇ ᴡɪʟʟ ᴅᴇғɪɴɪᴛᴇʟʏ ᴀɴsᴡᴇʀ ᴡʜᴇɴ ʜᴇ ɪs ᴏɴʟɪɴᴇ 🖤

ʟᴀsᴛ ᴏɴʟɪɴᴇ ᴛɪᴍᴇ » {endtime} ᴀɢᴏ""", reply_to=replylocation)
        except:
            pass

@events.register(events.NewMessage)
async def runmcfafk(event):
    checkmention = event.mentioned
    messagelocation = event.to_id
    replylocation = event.id
    try:
        if "on" in afkmode:
            if checkmention == True:
                end = datetime.now()
                total = (end - runafkon.start)
                countthetime = int(total.seconds)
                sd = countthetime // (24 * 3600)
                countthetime %= 24 * 3600
                sh = countthetime // 3600
                countthetime %= 3600
                sm = countthetime // 60
                countthetime %= 60
                ss = countthetime
                endtime = ""
                if sd > 0:
                    endtime += f"{sd}d {sh}h {sm}m {ss}s"
                elif sh > 0:
                    endtime += f"{sh}h {sm}m {ss}s"
                else:
                    endtime += f"{sm}m {ss}s" if sm > 0 else f"{ss}s"
                if runafkon.reason:
                    if ".afkon" in runafkon.reason:
                        await event.client.send_message(messagelocation, f"""sᴏʀʀʏ, ᴛʜᴇ ᴏᴡɴᴇʀ ᴏғ ᴛʜɪs ᴀᴄᴄᴏᴜɴᴛ ɪs ɴᴏᴛ ᴏɴʟɪɴᴇ ɴᴏᴡ 👤

ʟᴀsᴛ ᴏɴʟɪɴᴇ ᴛɪᴍᴇ » {endtime} ᴀɢᴏ""", reply_to=replylocation)
                    else:
                        await event.client.send_message(messagelocation, f"""sᴏʀʀʏ, ᴛʜᴇ ᴏᴡɴᴇʀ ᴏғ ᴛʜɪs ᴀᴄᴄᴏᴜɴᴛ ɪs ɴᴏᴛ ᴏɴʟɪɴᴇ ɴᴏᴡ 👤

ʟᴀsᴛ ᴏɴʟɪɴᴇ ᴛɪᴍᴇ » {endtime} ᴀɢᴏ""", reply_to=replylocation)
                else:
                    await event.client.send_message(messagelocation, f"""sᴏʀʀʏ, ᴛʜᴇ ᴏᴡɴᴇʀ ᴏғ ᴛʜɪs ᴀᴄᴄᴏᴜɴᴛ ɪs ɴᴏᴛ ᴏɴʟɪɴᴇ ɴᴏᴡ 👤

ʟᴀsᴛ ᴏɴʟɪɴᴇ ᴛɪᴍᴇ » {endtime} ᴀɢᴏ""", reply_to=replylocation)
    except:
        pass

#with client as Rs_Userbot:
#	Rs_Userbot.add_event_handler(runafkoff)
#	
#with client as Rs_Userbot:
#	Rs_Userbot.add_event_handler(runafkstatus)
#	
#with client as Rs_Userbot:
#	Rs_Userbot.add_event_handler(runafk)	

#with client as Rs_Userbot:
#	Rs_Userbot.add_event_handler(runmcfafk)

#with client as Rs_Userbot:
#	Rs_Userbot.add_event_handler(RsUserbot.runafkon)     