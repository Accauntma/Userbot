from telethon import TelegramClient, events, sync, functions, types, Button
import plugins.client
client = plugins.client.client
admins=plugins.client.admins
botClient = plugins.client.botClient
@botClient.on(events.InlineQuery)
async def _(query):
				if query.text == "ahelp":
								result = query.builder.article('Ahelp', text = """```ᴡᴇʟᴄᴏᴍᴇ ᴛᴏ ᴛʜᴇ ᴢᴇᴛᴜsᴇʀʙᴏᴛ ʜᴇʟᴘ ᴘᴀɴᴇʟ```
 ᴜsᴇ ᴛʜᴇ ʙᴜᴛᴛᴏɴs ʙᴇʟᴏᴡ ᴛᴏ ᴜsᴇ ᴜsᴇʀʙᴏᴛ 🌒""", buttons= [
								[Button.inline("⚙ ᴘʟᴜɢɪɴs", data=b"1"),Button.inline("🌘 ᴀɴɪᴍᴀᴛɪᴏɴs", data=b"2")],[Button.inline("⚡️ ғᴀᴋᴇ ᴀᴄᴛɪᴏɴs", data=b"3"),Button.inline("👮🏻‍♀ᴍᴏᴅᴇs", data=b"4")],[Button.inline("🎲 ɢᴀᴍᴇs", data=b"5"),Button.inline("👥 ɢʀᴏᴜᴘ ʜᴇʟᴘᴇʀs", data=b"6")],[Button.inline("👤 ᴀᴄᴄᴏᴜɴᴛ sᴇᴛᴛɪɴɢ", data=b"7"),Button.inline("ᴅᴇʟᴇᴛᴇ 🗑", data=b"8")]])
								await query.answer([result])


@botClient.on(events.CallbackQuery)
async def plugins(event):
    user_id = event.sender_id  # Get the user ID from event.sender_id

    if user_id in admins:
        if event.data == b'1':
            buttons = [
                [Button.inline("🌒 ʙᴀᴄᴋ ", data=b"back")]
            ]
            await event.edit("""```⚙ ᴘʟᴜɢɪɴs ᴄᴏᴍᴍᴀɴᴅs```

▫️𝙵𝙻𝙾𝙾𝙳 `.flood` <𝚃𝙸𝙼𝙴> <𝙲𝙾𝚄𝙽𝚃> <𝚃𝙴𝚇𝚃>
▫️𝙻𝙴𝚇𝙸𝙰𝚁𝚃 `.art` <𝚃𝙴𝚇𝚃>
▫️𝚂𝙷𝙾𝚁𝚃𝙴𝙽𝙴𝚁𝚂 `.short` <𝚄𝚁𝙻>
▫️𝙲𝙷𝙰𝚃𝙸𝙽𝙵𝙾 `.chat` <𝚄𝚂𝙴𝚁𝙽𝙰𝙼𝙴>
▫️𝚆𝙸𝙺𝙸𝙿𝙴𝙳𝙸𝙰
▫️
""", buttons=buttons)
        # Handle other plugin options here
    else:
        await event.answer('ʏᴏᴜ ɴᴏᴛ ɪɴsᴛᴀʟʟᴇᴅ ᴢᴇᴛᴜsᴇʀʙᴏᴛ | ',alert=True)



@botClient.on(events.CallbackQuery)
async def animations(event):
    user_id = event.sender_id  # Get the user ID from event.sender_id

    if user_id in admins:
        if event.data == b'2':
            buttons = [
                [Button.inline("🌒 ʙᴀᴄᴋ ", data=b"back")]
            ]
            await event.edit("""```🌘 ᴀɴɪᴍᴀᴛɪᴏɴ ᴄᴏᴍᴀɴᴅs```

◾️ sɴᴀᴋᴇ `.snake` 
◾️ ɴᴏᴛʜᴀᴘᴘʏ `.nothappy` 
◾️ ʜᴇᴀʀᴛs `.heart` 
◾️ ʟᴏᴏʟ `.lul` 
◾️ ᴄʟᴏᴡɴ `.clown` 
◾️ ᴄᴀɴᴅʏ `.candy`
◾️ ᴄʟᴏᴄᴋ `.clock`
◾️ ᴍᴜᴀʜ `.muah`
◾️ ᴇᴀʀᴛʜ `.earth`
◾️ ᴍᴏᴏɴ `.moon`
◾️ sᴍᴏᴏɴ `.smoon`
◾️ ᴛᴍᴏᴏɴ `.tmoon`
◾️ ᴄʏᴍɴᴀsᴛɪᴄ `.gym`
◾️ sᴇxʏ `.sexy`
◾️ ᴍᴀɢɪᴄ `.magic`
◾️ ᴘᴏʟɪᴄᴇ `.police`
◾️ ᴘʟᴀɴᴇ `.plane`
◾️ ғᴜᴄᴋ `.fuck`
◾️ ᴄᴏʟᴏʀ ʙᴏxs `.boxs`
◾️ ᴄʟᴏʟ `.clol`
◾️ ʙᴜᴛᴛᴇʀғʟʏ `.butter`
◾️ ᴏᴅʀᴀ `.odra`
◾️ ғʟᴇᴀᴠᴇᴍᴇ `.fleaveme`
◾️ ʟᴏᴠᴇᴜ `.loveu`
◾️ ᴊɪᴏ `.jio`
◾️ sᴏʟᴀʀsʏsᴛᴇᴍ `.solarsystem`
◾️ ʀᴀɪɴɪɴɢ `.raining`
◾️ sᴍɪʟᴇ `.smile`
◾️ sɴᴏᴡ `.snow`
◾️ ʜᴜɪ `.hui`
◾️ ᴛᴇxᴛ ᴛᴏ ʜᴇᴀʀᴛs `.emoji <text>`
◾️ ʟᴏᴠᴇʟʏ `.lovely`
◾️ ᴛᴜʀᴛʟᴇ `.turtle`
◾️ ᴅɪɴᴏ `.dino`
◾️ ʟᴏᴀᴅɪɴɢ `.loading`
◾️ ᴍᴀɢɪᴄ ᴘʀᴇᴍɪᴜᴍ `.pmagic`
◾️ ᴘᴏʏᴇᴢᴅ `.chukchuk`
◾️ ʟᴏᴠᴇ `.vlove`
◾️ ᴊᴜᴍᴀ `.juma`
◾️ ɴᴀʀᴜᴛᴏ `.naruto`""", buttons=buttons)
        # Handle other animation options here
    else:
        await event.answer('ʏᴏᴜ ɴᴏᴛ ɪɴsᴛᴀʟʟᴇᴅ ᴢᴇᴛᴜsᴇʀʙᴏᴛ | ',alert=True)




@botClient.on(events.CallbackQuery)
async def fakeactions(event):
    user_id = event.sender_id  # Get the user ID from event.sender_id

    if user_id in admins:
        if event.data == b'3':
            buttons = [
                [Button.inline("🌒 ʙᴀᴄᴋ ", data=b"back")]
            ]
            await event.edit("""```⚡️ ғᴀᴋᴇ ᴀᴄᴛɪᴏɴs ᴄᴏᴍᴍᴀɴᴅs```

◼️ ᴛʏᴘᴇ ғᴀᴋᴇ `.faketype `<time>
◼️ ᴠᴏɪᴄᴇ ғᴀᴋᴇ `.fakevoice `<time>
◼️ ɢᴀᴍᴇ ғᴀᴋᴇ `.fakegame `<time>
◼️ ᴘʜᴏᴛᴏ ғᴀᴋᴇ `.fakephoto `<time>
◼️ ᴠɪᴅᴇᴏ ғᴀᴋᴇ `.fakevideo `<time>
◼️ ғɪʟᴇ  ғᴀᴋᴇ `.fakedcmt `<time>
◼️ ʀᴏᴜɴᴅ ғᴀᴋᴇ `.fakeround `<time>
◼️ sᴛɪᴄᴋᴇʀ ғᴀᴋᴇ `.fakestick `<time>
◼️ ᴄᴏɴᴛᴀᴄᴛ ғᴀᴋᴇ `.fakecon `<time>
◼️ ʟᴏᴄᴀᴛɪᴏɴ ғᴀᴋᴇ `.fakeloc `<time>
◼️ ʀᴇᴀᴅ && ᴏɴʟɪɴᴇ 24/7 `.online`\n◼️ɪғ ʏᴏᴜ sᴇɴᴅ `.online` ᴀ sᴇᴄᴏɴᴅ ᴛɪᴍᴇ, ᴛʜᴇ ʀᴇᴀᴅ & ᴏɴʟɪɴᴇ ᴍᴏᴅᴇ ᴡɪʟʟ sᴛᴏᴘ ⚡️""", buttons=buttons)
        # Handle other actions options here
    else:
        await event.answer('ʏᴏᴜ ɴᴏᴛ ɪɴsᴛᴀʟʟᴇᴅ ᴢᴇᴛᴜsᴇʀʙᴏᴛ | ɪɴsᴛᴀʟʟ sᴇɴᴅ ᴍᴇssᴀɢᴇ @uzomedia',alert=True)




@botClient.on(events.CallbackQuery)
async def modes(event):
    user_id = event.sender_id  # Get the user ID from event.sender_id

    if user_id in admins:
        if event.data == b'4':
            buttons = [
                [Button.inline("🌒 ʙᴀᴄᴋ ", data=b"back")]
            ]
            await event.edit("""```👮🏻‍♀ ᴍᴏᴅᴇs ᴄᴏᴍᴍᴀɴᴅs```

```ʙʟᴏᴄᴋ ᴍᴏᴅᴇ 🚷```
◽️ʙʟᴏᴄᴋ ᴍᴏᴅᴇ ᴏɴ `.blockon`
◽️ʙʟᴏᴄᴋ ᴍᴏᴅᴇ ᴏғғ `.blockoff`
◽️ᴄʜᴇᴄᴋ ʙʟᴏᴄᴋ ᴍᴏᴅᴇ `.blockinfo`
◽️ᴄᴏɴғɪʀᴍᴀᴛɪᴏɴ `.pa`
◽️ʀᴇᴍᴏᴠᴇ ғʀᴏᴍ ᴀᴘᴘʀᴏᴠᴇᴅ `.pda`
◽️ʟɪsᴛ ᴏғ ᴠᴇʀɪғɪᴇᴅ ᴜsᴇʀs `.tlist`

```ᴀғᴋ ᴍᴏᴅᴇ 👤```
◽️ᴏɴ ᴀғᴋ ᴍᴏᴅᴇ `.afkon`
◽️ᴏғғ ᴀғᴋ ᴍᴏᴅᴇ `.afkoff`
◽️ᴀғᴋ sᴛᴀᴛᴜs ᴄʜᴇᴄᴋ `.afkinfo`
""", buttons=buttons)
        # Handle other modes options here
    else:
        await event.answer('ʏᴏᴜ ɴᴏᴛ ɪɴsᴛᴀʟʟᴇᴅ ᴢᴇᴛᴜsᴇʀʙᴏᴛ | ',alert=True)



@botClient.on(events.CallbackQuery)
async def games(event):
    user_id = event.sender_id  # Get the user ID from event.sender_id

    if user_id in admins:
        if event.data == b'5':
            buttons = [
                [Button.inline("🌒 ʙᴀᴄᴋ ", data=b"back")]
            ]
            await event.edit("""```🎲 ɢᴀᴍᴇs ᴄᴏᴍᴍᴀɴᴅs ```

◾ᴛɪᴄ ᴛᴀᴄ ᴛᴏᴇ `.tic-tac-toe`
◾ᴛɪᴄ ᴛᴀᴄ ғᴏᴜʀ `.tic-tac-four`
◾ᴇʟᴇᴘʜᴀɴᴛ xᴏ `.elephant-XO`
◾ᴄᴏɴɴᴇᴄᴛ ғᴏᴜʀ `.connect-four`
◾ᴄʜᴇᴄᴋᴇʀs `.checkers`
◾ᴘᴏᴏʟ ᴄʜᴇᴄᴋᴇʀs `.pool-checkers`
◾ʀᴜssɪᴀɴ ʀᴏᴜʟᴇᴛᴛᴇ `.russian-roulette`
◾ʀᴏᴄᴋ ᴘᴀᴘᴇʀ `.rock-paper`
◾ʀᴏᴄᴋ ᴘᴀᴘᴇʀ ʟɪᴢᴀʀᴅ `.lizard-rock-paper`
""", buttons=buttons)
        # Handle other games options here
    else:
        await event.answer('ʏᴏᴜ ɴᴏᴛ ɪɴsᴛᴀʟʟᴇᴅ ᴢᴇᴛᴜsᴇʀʙᴏᴛ | ',alert=True)



@botClient.on(events.CallbackQuery)
async def group(event):
    user_id = event.sender_id  # Get the user ID from event.sender_id

    if user_id in admins:
        if event.data == b'6':
            buttons = [
                [Button.inline("🌒 ʙᴀᴄᴋ ", data=b"back")]
            ]
            await event.edit("""```👥 ɢʀᴏᴜᴘ ʜᴇʟᴘᴇʀs ᴄᴏᴍᴍᴀɴᴅs```

◾sᴇᴀʀᴄʜ ᴅᴇʟᴇᴛᴇᴅ ᴀᴋᴀᴜɴᴛ `.sda`
◾ʀᴇᴍᴏᴠᴇ ᴅᴇʟᴇᴛᴇᴅ ᴀᴋᴀᴜɴᴛ `.rda`
◾sᴜᴘᴇʀ ᴀᴅᴍɪɴ `.superadmin <rank>`
◾ᴅᴇᴍᴏᴛᴇ ᴀᴅᴍɪɴ `.demote`
◾ᴘʀᴏᴍᴏᴛᴇ ᴀᴅᴍɪɴ `.promote <rank>`
◾ʙᴀɴ ᴜsᴇʀ `.ban <reason>`
◾ᴜɴʙᴀɴ ᴜsᴇʀ `.unban`
◾ᴍᴜᴛᴇ ᴜsᴇʀ `.tmute`
◾ᴜɴᴍᴜᴛᴇ `.unmute`
◾ᴍᴜᴛᴇ ᴛɪᴍᴇ `.mute <m/h/d/y>`
◾ᴘɪɴ ᴍᴇssᴀɢᴇ `.pin <reply>`
◾ᴜɴᴘɪɴ ᴍᴇssᴀɢᴇs `.unpin`
◾ʙᴀɴ ᴀʟʟ ᴜsᴇʀs `.banall`
◾ᴋɪᴄᴋ ᴀʟʟ ᴜsᴇʀs `.kickall`
""", buttons=buttons)
        # Handle other ɢʀᴏᴜᴘ options here
    else:
        await event.answer('ʏᴏᴜ ɴᴏᴛ ɪɴsᴛᴀʟʟᴇᴅ ᴢᴇᴛᴜsᴇʀʙᴏᴛ | ɪɴsᴛᴀʟʟ sᴇɴᴅ ᴍᴇssᴀɢᴇ  ',alert=True)



@botClient.on(events.CallbackQuery)
async def group(event):
    user_id = event.sender_id  # Get the user ID from event.sender_id

    if user_id in admins:
        if event.data == b'7':
            buttons = [
                [Button.inline("🌒 ʙᴀᴄᴋ ", data=b"back")]
            ]
            await event.edit("""```👤 ᴀᴄᴄᴏᴜɴᴛ sᴇᴛᴛɪɴɢ ᴄᴏᴍᴍᴀɴᴅs```

◾ᴜsᴇʀɴᴀᴍᴇ ᴄʜᴀɴɢᴇ `.username `<username>
◾ɴɪᴄᴋɴᴀᴍᴇ ᴄʜᴀɴɢᴇ `.nickname `<nickname>
◾ʟᴀsᴛ ɴᴀᴍᴇ ᴄʜᴀɴɢᴇ `.lastname `<lastname>
◾ʙɪᴏ ᴄʜᴀɴɢᴇ (ᴀʙᴏᴜᴛ) `.biochange `<text>
""", buttons=buttons)
        # Handle other ᴀᴄᴏᴜɴᴛ options here
    else:
        await event.answer('ʏᴏᴜ ɴᴏᴛ ɪɴsᴛᴀʟʟᴇᴅ ᴢᴇᴛᴜsᴇʀʙᴏᴛ | ɪɴsᴛᴀʟʟ sᴇɴᴅ ᴍᴇssᴀɢᴇ ',alert=True)



@botClient.on(events.CallbackQuery)
async def back(event):
    user_id = event.sender_id  # Get the user ID from event.sender_id

    if user_id in admins:
        if event.data == b'back':
            buttons= [
								[Button.inline("⚙ ᴘʟᴜɢɪɴs", data=b"1"),Button.inline("🌘 ᴀɴɪᴍᴀᴛɪᴏɴs", data=b"2")],[Button.inline("⚡️ ғᴀᴋᴇ ᴀᴄᴛɪᴏɴs", data=b"3"),Button.inline("👮🏻‍♀ᴍᴏᴅᴇs", data=b"4")],[Button.inline("🎲 ɢᴀᴍᴇs", data=b""),Button.inline("👥 ɢʀᴏᴜᴘ ʜᴇʟᴘᴇʀs", data=b"6")],[Button.inline("👤 ᴀᴄᴄᴏᴜɴᴛ sᴇᴛᴛɪɴɢ", data=b"7"),Button.inline("ᴅᴇʟᴇᴛᴇ 🗑", data=b"8")]]
            await event.edit("""```ʏᴏᴜ ʜᴀᴠᴇ ʀᴇᴛᴜʀɴᴇᴅ ᴛᴏ ᴛʜᴇ ᴍᴀɪɴ ᴍᴇɴᴜ```
ʏᴏᴜ ᴄᴀɴ ᴜsᴇ ʀsᴜsᴇʀʙᴏᴛ ᴡɪᴛʜ ᴛʜᴇ ʜᴇʟᴘ ᴏғ ᴛʜᴇ ʙᴜᴛᴛᴏɴs ʙᴇʟᴏᴡ 🌒""", buttons=buttons)
        # Handle other back options here
    else:
        await event.answer('ʏᴏᴜ ɴᴏᴛ ɪɴsᴛᴀʟʟᴇᴅ ᴢᴇᴛᴜsᴇʀʙᴏᴛ | ɪɴsᴛᴀʟʟ sᴇɴᴅ ᴍᴇssᴀɢᴇ ',alert=True)




@events.register(events.NewMessage(outgoing=True,pattern=".help"))
async def help(event):
				results = await client.inline_query("@ZetUserbot", "ahelp")
				await results[0].click(event.chat_id)
				await event.message.delete()
with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(help)
