#◻ Server ping  - .ping



#©️By : @RasulBekDev
#✘ Powered By: Rs Userbot

from telethon import events, types, utils
from plugins.client import client
import os
import re
import youtube_dl
from pytgcalls import PyTgCalls, StreamType
from pytgcalls.types.input_stream import AudioPiped, AudioVideoPiped
from pytgcalls.types.input_stream.quality import HighQualityAudio, HighQualityVideo

pytgcalls_instance = PyTgCalls(client)


async def parse_args(args):
    if not args or not re.match(
        r"http(?:s?):\/\/(?:www\.)?youtu(?:be\.com\/watch\?v=|\.be\/)([\w\-\_]*)(&(amp;)?‌​[\w\?‌​=]*)?",
        args,
    ):
        return args
    with youtube_dl.YoutubeDL({"format": "best"}) as ydl:
        info = ydl.extract_info(args, download=False)
        return info["formats"][0]["url"]


# Function to parse arguments




async def get_args(message):
    split_text = message.text.split(maxsplit=1)
    if len(split_text) > 1:
        return split_text[1]
    else:
        return ''

# Event handlers
@events.register(events.NewMessage(pattern=r'\.cdl', outgoing=True))
async def cdl_handler(event):
    args = await get_args(event.message)
    reply = await event.get_reply_message()
    if not reply:
        return await event.respond("No reply")
    name = args or reply.file.name
    try:
        await event.respond("<b>[ChatVoiceMod]</b> Downloading...")
        await reply.download_media(f"dl/{name}")
        await event.respond(f"<b>[ChatVoiceMod]</b> Downloaded to <code>dl/{name}</code>. For playing use:\n<code>.cplaya dl/{name}</code>\n<code>.cplayv dl/{name}</code>")
    except Exception as e:
        await event.respond(f"<b>[ChatVoiceMod]</b> Error: <code>{str(e)}</code>")

@events.register(events.NewMessage(pattern=r'\.clsc', outgoing=True))
async def clsc_handler(event):
    if not os.path.isdir("dl") or not os.listdir("dl"):
        return await event.respond("<b>[ChatVoiceMod]</b> No files")
    files = [f"<code>dl/{f}</code>" for f in os.listdir("dl")]
    await event.respond("\n".join(files))

@events.register(events.NewMessage(pattern=r'\.cdel', outgoing=True))
async def cdel_handler(event):
    args = await get_args(event.message)
    if not args:
        return await event.respond("No args")
    if not args.startswith("dl/"):
        args = f"dl/{args}"
    if not os.path.isfile(f"{args}"):
        return await event.respond("No file")
    try:
        os.remove(f"{args}")
        await event.respond(f"<b>[ChatVoiceMod]</b> <code>{args}</code> successfully deleted")
    except Exception as e:
        await event.respond(f"<b>[ChatVoiceMod]</b> Error: <code>{str(e)}</code>")

# Define other command handlers similarly

@events.register(events.NewMessage(pattern=r'\.cleave', outgoing=True))
async def cleave_handler(event):
    try:
        await event.respond("<b>[ChatVoiceMod]</b> Leaved!")
        await pytgcalls.leave_group_call(event.chat_id)
    except pytgcalls.exceptions.GroupCallNotFound:
        await event.respond("<b>[ChatVoiceMod]</b> You are not joined")
    except Exception as e:
        await event.respond(f"<b>[ChatVoiceMod]</b> Error: <code>{str(e)}</code>")

# Define other command handlers similarly

# Define other command handlers similarly

@events.register(events.NewMessage(pattern=r'\.cmutec', outgoing=True))
async def cmutec_handler(event):
    try:
        await event.respond("<b>[ChatVoiceMod]</b> Muted!")
        await pytgcalls_instance.mute_stream(event.chat_id)
    except pytgcalls.exceptions.GroupCallNotFound:
        await event.respond("<b>[ChatVoiceMod]</b> You are not joined")
    except Exception as e:
        await event.respond(f"<b>[ChatVoiceMod]</b> Error: <code>{str(e)}</code>")

@events.register(events.NewMessage(pattern=r'\.cunmutec', outgoing=True))
async def cunmutec_handler(event):
    try:
        await event.respond("<b>[ChatVoiceMod]</b> Unmuted!")
        await pytgcalls_instance.unmute_stream(event.chat_id)
    except pytgcalls.exceptions.GroupCallNotFound:
        await event.respond("<b>[ChatVoiceMod]</b> You are not joined")
    except Exception as e:
        await event.respond(f"<b>[ChatVoiceMod]</b> Error: <code>{str(e)}</code>")

@events.register(events.NewMessage(pattern=r'\.cpause', outgoing=True))
async def cpause_handler(event):
    try:
        await event.respond("<b>[ChatVoiceMod]</b> Paused!")
        await pytgcalls_instance.pause_stream(event.chat_id)
    except pytgcalls.exceptions.GroupCallNotFound:
        await event.respond("<b>[ChatVoiceMod]</b> You are not joined")
    except Exception as e:
        await event.respond(f"<b>[ChatVoiceMod]</b> Error: <code>{str(e)}</code>")

@events.register(events.NewMessage(pattern=r'\.cresume', outgoing=True))
async def cresume_handler(event):
    try:
        await event.respond("<b>[ChatVoiceMod]</b> Resumed!")
        await pytgcalls_instance.resume_stream(event.chat_id)
    except pytgcalls.exceptions.GroupCallNotFound:
        await event.respond("<b>[ChatVoiceMod]</b> You are not joined")
    except Exception as e:
        await event.respond(f"<b>[ChatVoiceMod]</b> Error: <code>{str(e)}</code>")


@events.register(events.NewMessage(pattern=r'\.cplaya', outgoing=True))
async def cplaya_handler(event):
    try:
        reply = await event.get_reply_message()
        args = event.raw_text.split(' ', 1)[1] if event.raw_text.split(' ', 1)[1:] else ""  # получение аргументов с проверкой
        path = await parse_args(args)
        chat = event.chat_id
        if not path:
            if not reply:
                return await event.respond("<b>[ChatVoiceMod]</b> No args")
            await event.respond("<b>[ChatVoiceMod]</b> Downloading...")
            path = await reply.download_media()
        pytgcalls_instance.get_active_call(chat)
        await pytgcalls_instance.leave_group_call(chat)
        await pytgcalls_instance.join_group_call(
            chat,
            AudioPiped(
                path,
                HighQualityAudio(),
            ),
            stream_type=StreamType().pulse_stream,
        )
        await event.respond("<b>[ChatVoiceMod]</b> Playing...")
    except Exception as e:
        await event.respond(f"<b>[ChatVoiceMod]</b> Error: <code>{str(e)}</code>")

@events.register(events.NewMessage(pattern=r'\.cplayv', outgoing=True))
async def cplayv_handler(event):
    try:
        reply = await event.get_reply_message()
        args = event.raw_text.split(' ', 1)[1] if event.raw_text.split(' ', 1)[1:] else ""  # получение аргументов с проверкой
        path = await parse_args(args)
        chat = event.chat_id
        if not path:
            if not reply:
                return await event.respond("<b>[ChatVoiceMod]</b> No args")
            await event.respond("<b>[ChatVoiceMod]</b> Downloading...")
            path = await reply.download_media()
        pytgcalls_instance.get_active_call(chat)
        await pytgcalls_instance.leave_group_call(chat)
        await pytgcalls_instance.join_group_call(
            chat,
            AudioVideoPiped(
                path,
                HighQualityAudio(),
                HighQualityVideo(),
            ),
            stream_type=StreamType().pulse_stream,
        )
        await event.respond("<b>[ChatVoiceMod]</b> Playing...")
    except Exception as e:
        await event.respond(f"<b>[ChatVoiceMod]</b> Error: <code>{str(e)}</code>")



with client as StreamModule:
	StreamModule.add_event_handler(cplayv_handler)
	StreamModule.add_event_handler(cplaya_handler)
	StreamModule.add_event_handler(cresume_handler)
	StreamModule.add_event_handler(cpause_handler)
	StreamModule.add_event_handler(cunmutec_handler)
	StreamModule.add_event_handler(cmutec_handler)
	StreamModule.add_event_handler(cleave_handler)
	StreamModule.add_event_handler(cdel_handler)
	
	