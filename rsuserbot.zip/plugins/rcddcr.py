from os import remove
from telethon import TelegramClient, events
import plugins.client
from time import sleep
client = plugins.client.client

@events.register(events.NewMessage(outgoing=True, pattern=r'\.rcd'))
async def rundrc(event):
    await event.delete()
    try:
        getrestrictedcontent = await event.get_reply_message()
        downloadrestrictedcontent = await getrestrictedcontent.download_media()
        await event.client.send_file("me", downloadrestrictedcontent)
        remove(downloadrestrictedcontent)
    except:
        pass

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(rundrc)        