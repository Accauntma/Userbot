from telethon import TelegramClient, events, sync
from time import sleep
from datetime import datetime
import asyncio, aiocron, datetime
import phonenumbers
from phonenumbers import carrier, geocoder, timezone
from sys import stderr
from plugins.client import client

client=client

@events.register(events.NewMessage(pattern=r".numinfo", outgoing=True))
async def numinfo(event):
    if not event.is_reply:
        await event.edit("Please reply with the phone number 💡")
        return
    reply_msg = await event.get_reply_message()
    if not reply_msg.text:
        await event.edit("For text messages only please 💡")
        return
    try:
        phone_number = reply_msg.text.strip()
        default_region="uz"
        parsed_number = phonenumbers.parse(phone_number, None)
        await event.edit(f"☎ Phone number {phone_number}\n📟 Number code +{parsed_number.country_code}\n📍 Location {geocoder.description_for_number(parsed_number, 'en')}\n⌨ Number type {phonenumbers.number_type(parsed_number )}\n⏳ Time zone {timezone.time_zones_for_number(parsed_number)}\n🪬 Possible number {phonenumbers.is_possible_number(parsed_number)}\n® Region code {phonenumbers.region_code_for_number(parsed_number)}\n🧿 Valid number {phonenumbers.is_valid_number(parsed_number)}\n🔮 Local number {parsed_number.national_number}\n🔖 Country code {parsed_number.country_code}\n📱 Mobile format {phonenumbers.format_number_for_mobile_dialing(parsed_number, default_region, with_formatting=True)}\n👩‍💻 Operator {carrier.name_for_number(parsed_number,'en')}\n♻️ E.164 format {phonenumbers.format_number(parsed_number, phonenumbers.PhoneNumberFormat.E164)} \n⚜ Original number {parsed_number.national_number}\n🔰 International format {phonenumbers.format_number(parsed_number, phonenumbers.PhoneNumberFormat.INTERNATIONAL)}")
    except phonenumbers.NumberParseException:
        await event.edit("The phone number is in the wrong format 📵")

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(numinfo)