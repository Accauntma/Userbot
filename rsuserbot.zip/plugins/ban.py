from telethon.sync import TelegramClient, events
from telethon.tl import types
import plugins.client

client=plugins.client.client

from telethon.sync import TelegramClient, events


@event.register(events.NewMessage(pattern=r'@(?!ban|unban)'))
async def ban_user(event):
    # Check if the message mentions the target username
    if target_username in event.raw_text:
        sender_user_id = event.sender_id
        
        # Check if the sender has admin rights (optional)
        if await is_admin(event.chat_id, sender_user_id):
            await event.reply(f'You have been banned from mentioning {target_username}.')
            await ban_user_action(event.chat_id, sender_user_id)
        else:
            await event.reply(f'You do not have permission to ban users.')

async def is_admin(chat_id, user_id):
    # Implement a function to check if the user is an admin in the chat
    # Return True if the user is an admin, False otherwise
    # Example implementation: return True if user_id is an admin in chat_id

async def ban_user(chat_id, user_id):
    # Implement the ban action here
    # Use the client to ban the user from the chat
    # Example implementation: await client.edit_permissions(chat_id, user_id, send_messages=False)

if __name__ == '__main__':


with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(ban_user)