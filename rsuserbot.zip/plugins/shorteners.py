from telethon import TelegramClient, events, sync
from pyshorteners import Shortener
from plugins.client import client
import time

client=client
s = Shortener()

".shorturl"
SHORTNET_PATTERN = r'^\.shorturl\s+(.*)$'

@events.register(events.NewMessage(outgoing=True,pattern=SHORTNET_PATTERN))
async def shorten_links(event):
    await event.edit("🌐 ᴘʟɪsᴇ ᴡᴀɪᴛ ...")
    time.sleep(2)
    
    link = event.pattern_match.group(1)

    
    if link.startswith("https://"):
        
        tiny_url = s.tinyurl.short(link)
        isgd_url = s.isgd.short(link)
        dagd_url = s.dagd.short(link)
        osdb_url = s.osdb.short(link)

        
        message = f"🌐 ᴜʀʟ sʜᴏʀᴛᴇɴᴇʀ 🌐\n\n🌐 {tiny_url}\n🌐 {isgd_url}\n🌐 {dagd_url}\n🌐 {osdb_url}"

        
        await event.edit(message)

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(shorten_links)