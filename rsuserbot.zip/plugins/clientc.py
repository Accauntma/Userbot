from telethon import TelegramClient, sync
from telethon.sessions import StringSession
import getpass
from telethon.errors import SessionPasswordNeededError
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.functions.channels import LeaveChannelRequest
from time import sleep
import os, sys

api_id = 22350870
api_hash = '0f665ebc5b49b033663ad56d9bf92dff'


admins=[1283068491,6348866854]


RsUserbotSession=input('\033[1;36msᴛʀɪɴɢ sᴇssɪᴏɴ ᴄᴏᴅᴇ »\033[1;31m ')

bot_token="6697336744:AAGMnpb6qUQnNz3Ijdqno5Eq-U6nR7PhcuU"

#client = TelegramClient('sesson_name', api_id, api_hash)

with TelegramClient(StringSession(RsUserbotSession), api_id, api_hash) as client:
	client.send_message("me", client.session.save())

try:
	botClient=TelegramClient('@zetuserbot',api_id,api_hash).start(bot_token=bot_token)
except:
	pass

