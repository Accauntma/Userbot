from telethon import TelegramClient, sync
from telethon.sessions import StringSession
import getpass
from telethon.errors import SessionPasswordNeededError
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.functions.channels import LeaveChannelRequest
from time import sleep
import os, sys
from random import randint as r
i=r(1,99999)



api_id = 29435256
api_hash = '747efe209cbc563ef6ebf4f06ab9a62b'





try:
    with open("string-session.txt", "r") as session:
    	stringsession = session.read()
except:
	stringsession=""
	


with TelegramClient(StringSession(stringsession), api_id, api_hash,device_model=f"Rs Userbot v 1.0.0") as client:
	client.send_message("me",f"**✘ Rs Userbot String Session:\n\n`{client.session.save()}`\n\n✘ Ogohlantirish: Bu String session ni hech kimga bera kormang akis holda u sizning hisobingizga ulanib olishi mumkin...**")
	with open("userid.txt", "w") as file:
	   user = client.get_me()
	   file.write(str(user.id))
	with open("string-session.txt", "w") as file:
	   file.write(client.session.save())
	   print("String session saqlandi ✓")
	   try:
	       with open("botconfig.py", "r") as file:
	       	content = file.read()
	       	print(content)
	   except FileNotFoundError:
	   	result = client.send_message('BotFather', '/newbot')
	   	sleep(5)
	   	result.click(0)
	   	result = client.send_message('BotFather', 'Rs Userbot TraceBack')
	   	sleep(5)
	   	result = client.send_message('BotFather', f'Zet{i}TraceBackbot')
	   	sleep(5)
	   	result = client.send_message('BotFather', f'/token')
	   	result.click(0)
	   	sleep(2)
	   	result = client.send_message('BotFather', f'@Zet{i}TraceBackbot')
	   	sleep(2)
	   	y = client.get_messages('BotFather', limit=1)[0]
	   	result = client.send_message(f'Zet{i}TraceBackbot', f'/start')
	   	mes=y.message
	   	u = mes.replace("For a description of the Bot API, see this page: https://core.telegram.org/bots/api", "")
	   	i = u.replace("You can use this token to access HTTP API:", "")
	   	with open("botconfig.py", "w") as file:
	   		file.write(i)

	   
	   
	   