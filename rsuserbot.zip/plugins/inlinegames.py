from telethon import TelegramClient, events, sync, functions, types ,Button
import plugins.client
client = plugins.client.client

#ɢᴀᴄʜɪ ᴍᴜᴄʜɪ ʙᴏʙ ᴋᴇᴛɪʙsᴀɴᴜ ᴜᴋᴀᴍ ᴍᴀɴɪ ᴋᴏᴅʟᴀʀᴋᴍɢᴀ ᴋʀɪʙ ᴋᴏʀᴠᴏsᴀɴ ʏᴇ ǫᴏᴅɪʀᴀʟɪ ǫᴏʏɪʟ 💩😹


@events.register(events.NewMessage(outgoing=True,pattern=".tic-tac-toe"))
async def tictactoe(event):
				results = await client.inline_query("@inlinegamesbot", "Tic-Tac-Toe")
				await results[0].click(event.chat_id)
				await event.message.delete()


@events.register(events.NewMessage(outgoing=True,pattern=".tic-tac-four"))
async def tictacfour(event):
				results = await client.inline_query("@inlinegamesbot", "Tic-Tac-Four")
				await results[1].click(event.chat_id)
				await event.message.delete()


@events.register(events.NewMessage(outgoing=True,pattern=".elephant-XO"))
async def elephantXO(event):
				results = await client.inline_query("@inlinegamesbot", "Elephant XO")
				await results[2].click(event.chat_id)
				await event.message.delete()
				


@events.register(events.NewMessage(outgoing=True,pattern=".connect-four"))
async def connectfour(event):
				results = await client.inline_query("@inlinegamesbot", "Connect Four")
				await results[3].click(event.chat_id)
				await event.message.delete()


@events.register(events.NewMessage(outgoing=True,pattern=".rock-paper"))
async def rockpaper(event):
				results = await client.inline_query("@inlinegamesbot", "Rock-Paper-Scissors")
				await results[4].click(event.chat_id)
				await event.message.delete()
				

@events.register(events.NewMessage(outgoing=True,pattern=".lizard-rock-paper"))
async def rockpaperlizard(event):
				results = await client.inline_query("@inlinegamesbot", "Rock-Paper-Scissors-Lizard-Spock")
				await results[5].click(event.chat_id)
				await event.message.delete()



@events.register(events.NewMessage(outgoing=True,pattern=".lizard-rock-paper"))
async def rockpaperlizard(event):
				results = await client.inline_query("@inlinegamesbot", "Rock-Paper-Scissors-Lizard-Spock")
				await results[5].click(event.chat_id)
				await event.message.delete()


@events.register(events.NewMessage(outgoing=True,pattern=".russian-roulette"))
async def roulette(event):
				results = await client.inline_query("@inlinegamesbot", "Russian Roulette")
				await results[6].click(event.chat_id)
				await event.message.delete()


@events.register(events.NewMessage(outgoing=True,pattern=".checkers"))
async def checkers(event):
				results = await client.inline_query("@inlinegamesbot", "Checkers")
				await results[7].click(event.chat_id)
				await event.message.delete()


@events.register(events.NewMessage(outgoing=True,pattern=".pool-checkers"))
async def polcheckers(event):
				results = await client.inline_query("@inlinegamesbot", "Pool-Checkers")
				await results[8].click(event.chat_id)
				await event.message.delete()




with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(polcheckers)

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(checkers)

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(roulette)

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(rockpaperlizard)

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(rockpaper)

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(connectfour)

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(elephantXO)

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(tictacfour)

with client as Rs_Userbot:
	Rs_Userbot.add_event_handler(tictactoe)