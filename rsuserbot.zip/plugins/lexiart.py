from telethon import TelegramClient, events
from io import BytesIO
import random
import requests
from plugins.client import client

client = client

@events.register(events.NewMessage(pattern='.art', outgoing=True))
async def art(event):
    await event.edit("• ᴘʟɪsᴇ ᴡᴀɪᴛ .... ")
    url = 'https://lexica.art/api/infinite-prompts'
    args = event.raw_text.split(".art ", maxsplit=1)[1]
    data = {
        "text": f"{args}",
        "searchMode": "images",
        "source": "search",
        "cursor": 0,
        "model": "lexica-aperture-v2"
    }
    headers = {
        'content-type': 'application/json',
        'cookie': 'https%3A%2F%2Flexica.art%2F%3Fq%3Dcar%2Bparking%2Bzone',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
    }
    r = requests.post(url, json=data, headers=headers)
    jss = r.json()
    ids = [image['id'] for image in jss['images']]
    selected_ids = random.sample(ids, 1)
    media = []
    for image_id in selected_ids:
        image_url = f"https://lexica-serve-encoded-images2.sharif.workers.dev/md2/{image_id}"
        response = requests.get(image_url)
        photo = BytesIO(response.content)
        photo.name = f"{image_id}.png"
        media.append(photo)
    await event.delete()
    for photo in media:
        await event.client.send_file(event.chat_id, photo,caption=f"ʏᴏᴜʀ ᴏʀᴅᴇʀ » `{args}`")

with client as Rs_Userbot:
    Rs_Userbot.add_event_handler(art)

