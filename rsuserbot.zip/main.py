#ᴀᴠᴛᴏᴍᴇᴛɪᴄ ɪɴsᴛᴀʟʟ ʟɪʙʀᴀʀʏs

import os

try:
	import telethon
	import phonenumbers
	import pyshorteners
	import bs4
	import emoji
	import aiocron
except:
	print("\033[1;31mɪɴsᴛᴀʟɪɴɢ ʟɪɴʀᴀʀɪʏs ᴘʟɪsᴇ ᴡᴀɪᴛ (:\n")
	print("\033[1;32m")
	os.system("pip install telethon && clear")
	os.system("pip install phonenumbers && clear ")
	os.system("pip install pyshorteners && clear")
	os.system("pip install bs4 && clear")
	os.system("pip install emoji && clear ")
	os.system("pip install aiocron && clear")

from telethon import TelegramClient, events, sync
from telethon.sessions import StringSession
from time import sleep


#ɪᴍᴘᴏʀᴛ ᴘʟᴜɢɪɴs

from plugins import client , online , fakeaction,clock ,currency , encoder ,gitsave, help , htmldown ,inlinegames , koop, lexiart , number , numberinfo ,type , shorteners, chatinfo , antion 

#ɪᴍᴘᴏʀᴛ ᴀɴɪᴍᴀᴛɪᴏɴs 

from animations import alo , animation , animationtwo, emoji , fuck , juma,loading,lovely , love ,smilerun , snow ,umod , Reklama
#ᴄʟɪᴇɴᴛ ᴜsᴇʀʙᴏᴛ 


client = client.client



#ᴀᴅᴅ ᴇᴠᴇɴᴛ ʜᴀɴᴅʟᴇʀs

	
client.start()
print("\033[1;31mᴜsᴇʀʙᴏᴛ sᴛᴀʀᴛᴇᴅ")
client.run_until_disconnected()

